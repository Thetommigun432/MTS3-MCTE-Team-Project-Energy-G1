export function UIKit() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-2xl mb-6 text-neutral-800">UI Kit — Wireframe Components</div>
        
        <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto p-8">
          
          {/* Buttons */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Buttons</div>
            <div className="flex flex-wrap gap-3">
              <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm">
                Primary Button
              </div>
              <div className="px-5 py-2.5 border-2 border-neutral-700 bg-white text-sm">
                Secondary Button
              </div>
              <div className="px-5 py-2.5 border border-neutral-500 bg-neutral-100 text-sm">
                Tertiary Button
              </div>
              <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-300 text-neutral-600 text-sm cursor-not-allowed">
                Disabled Button
              </div>
            </div>
          </div>
          
          {/* Inputs */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Input Fields</div>
            <div className="space-y-3 max-w-md">
              <div>
                <div className="text-xs text-neutral-700 mb-1">Text Input</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[Placeholder text]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Disabled Input</div>
                <div className="border-2 border-neutral-500 bg-neutral-100 px-3 py-2">
                  <div className="text-xs text-neutral-400">[Disabled]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Textarea</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2 h-20">
                  <div className="text-xs text-neutral-400">[Multiline text...]</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Dropdowns */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Dropdowns & Selects</div>
            <div className="flex gap-4">
              <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between min-w-[160px]">
                <span className="text-xs">Select option</span>
                <div className="w-3 h-3 border-l border-b border-neutral-700 transform rotate-45 translate-y-[-2px]"></div>
              </div>
              
              <div className="border-2 border-neutral-600 bg-neutral-100 px-3 py-2 flex items-center justify-between min-w-[160px]">
                <span className="text-xs text-neutral-500">Disabled</span>
                <div className="w-3 h-3 border-l border-b border-neutral-500 transform rotate-45 translate-y-[-2px]"></div>
              </div>
            </div>
          </div>
          
          {/* Checkboxes & Radio */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Checkboxes & Radio Buttons</div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-neutral-800"></div>
                <span className="text-xs text-neutral-700">Checkbox checked</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-white"></div>
                <span className="text-xs text-neutral-700">Checkbox unchecked</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-neutral-800 rounded-full relative">
                  <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                </div>
                <span className="text-xs text-neutral-700">Radio selected</span>
              </div>
            </div>
          </div>
          
          {/* Toggles */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Toggle Switches</div>
            <div className="flex gap-4">
              <div className="w-12 h-6 border-2 border-neutral-700 bg-neutral-800 rounded-full relative">
                <div className="w-4 h-4 bg-white rounded-full absolute right-1 top-0.5"></div>
              </div>
              <div className="w-12 h-6 border-2 border-neutral-700 bg-neutral-200 rounded-full relative">
                <div className="w-4 h-4 bg-white rounded-full absolute left-1 top-0.5"></div>
              </div>
            </div>
          </div>
          
          {/* Cards */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Cards</div>
            <div className="grid grid-cols-3 gap-4">
              <div className="border-2 border-neutral-700 bg-white p-4">
                <div className="text-xs text-neutral-600 mb-2">Card Label</div>
                <div className="text-2xl text-neutral-900">Value</div>
                <div className="text-xs text-neutral-500 mt-1">Subtext</div>
              </div>
              
              <div className="border border-neutral-400 bg-neutral-50 p-4">
                <div className="text-xs text-neutral-600 mb-2">Subtle Card</div>
                <div className="text-2xl text-neutral-900">Value</div>
                <div className="text-xs text-neutral-500 mt-1">Subtext</div>
              </div>
              
              <div className="border-2 border-neutral-800 bg-neutral-800 text-white p-4">
                <div className="text-xs text-neutral-300 mb-2">Dark Card</div>
                <div className="text-2xl">Value</div>
                <div className="text-xs text-neutral-400 mt-1">Subtext</div>
              </div>
            </div>
          </div>
          
          {/* Tables */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Table</div>
            <div className="border-2 border-neutral-700 bg-white">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-neutral-400 bg-neutral-100">
                    <th className="text-left px-4 py-2 text-neutral-700">Column 1</th>
                    <th className="text-left px-4 py-2 text-neutral-700">Column 2</th>
                    <th className="text-left px-4 py-2 text-neutral-700">Column 3</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-neutral-300">
                    <td className="px-4 py-2.5">Data 1</td>
                    <td className="px-4 py-2.5">Data 2</td>
                    <td className="px-4 py-2.5">Data 3</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2.5">Data 1</td>
                    <td className="px-4 py-2.5">Data 2</td>
                    <td className="px-4 py-2.5">Data 3</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Chart Placeholders */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Chart Placeholders</div>
            <div className="grid grid-cols-2 gap-4">
              <div className="h-40 border-2 border-neutral-400 bg-neutral-50 flex items-center justify-center text-xs text-neutral-600">
                [Line Chart Placeholder]
              </div>
              <div className="h-40 border-2 border-neutral-400 bg-neutral-50 flex items-center justify-center text-xs text-neutral-600">
                [Area Chart Placeholder]
              </div>
            </div>
          </div>
          
          {/* Badges & Pills */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Badges & Status Pills</div>
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-0.5 bg-neutral-800 text-white text-xs">Active</span>
              <span className="px-2 py-0.5 border border-neutral-600 bg-neutral-200 text-xs">Inactive</span>
              <span className="px-2 py-0.5 bg-green-100 border border-green-400 text-green-900 text-xs">Success</span>
              <span className="px-2 py-0.5 bg-yellow-100 border border-yellow-400 text-yellow-900 text-xs">Warning</span>
              <span className="px-2 py-0.5 bg-red-100 border border-red-400 text-red-900 text-xs">Error</span>
            </div>
          </div>
          
          {/* Banners */}
          <div className="mb-8">
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Banners & Alerts</div>
            <div className="space-y-3">
              <div className="bg-neutral-200 border-2 border-neutral-400 px-4 py-3 text-xs text-neutral-800">
                <strong>Info:</strong> This is an informational banner
              </div>
              <div className="bg-yellow-100 border-2 border-yellow-400 px-4 py-3 text-xs text-yellow-900">
                <strong>Warning:</strong> This is a warning banner
              </div>
              <div className="bg-red-100 border-2 border-red-400 px-4 py-3 text-xs text-red-900">
                <strong>Error:</strong> This is an error banner
              </div>
            </div>
          </div>
          
          {/* Icons Placeholders */}
          <div>
            <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Icon Placeholders</div>
            <div className="flex gap-4">
              <div className="w-8 h-8 border-2 border-neutral-700 bg-neutral-300"></div>
              <div className="w-6 h-6 border-2 border-neutral-700 bg-neutral-300"></div>
              <div className="w-4 h-4 border-2 border-neutral-700 bg-neutral-300"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
