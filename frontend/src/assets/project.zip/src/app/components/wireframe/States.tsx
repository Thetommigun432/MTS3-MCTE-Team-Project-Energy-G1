import { Loader2, AlertCircle, Lock, Inbox } from 'lucide-react';

export function States() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-2xl mb-6 text-neutral-800">Application States</div>
        
        <div className="grid grid-cols-2 gap-6">
          
          {/* STATE 1: LOADING */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">Loading State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Dashboard</div>
              </div>
              
              {/* Content with loading */}
              <div className="flex-1 p-6 bg-neutral-100 flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="w-12 h-12 text-neutral-700 animate-spin mx-auto mb-4" />
                  <div className="text-sm text-neutral-800 mb-1">Loading data...</div>
                  <div className="text-xs text-neutral-600">Please wait</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 2: EMPTY DATA */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">Empty Data State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Dashboard</div>
              </div>
              
              {/* Empty state */}
              <div className="flex-1 p-6 bg-neutral-50 flex items-center justify-center">
                <div className="text-center max-w-md">
                  <Inbox className="w-16 h-16 text-neutral-500 mx-auto mb-4" />
                  <div className="text-sm text-neutral-800 mb-2">No data available</div>
                  <div className="text-xs text-neutral-600 mb-4">
                    There is no energy consumption data for this date range. Try selecting a different date range or building.
                  </div>
                  <div className="px-4 py-2 border border-neutral-700 bg-white text-xs inline-block cursor-pointer hover:bg-neutral-50">
                    Change Filters
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 3: ERROR */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">Error State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Dashboard</div>
              </div>
              
              {/* Error banner */}
              <div className="bg-red-100 border-b-2 border-red-400 px-4 py-3 flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-800 shrink-0" />
                <div className="text-xs text-red-900">
                  <strong>Failed to load data</strong> — Check your connection or switch to Demo Mode
                </div>
              </div>
              
              {/* Error content */}
              <div className="flex-1 p-6 bg-neutral-100 flex items-center justify-center">
                <div className="text-center max-w-md">
                  <AlertCircle className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                  <div className="text-sm text-neutral-800 mb-2">Unable to load dashboard</div>
                  <div className="text-xs text-neutral-600 mb-4">
                    The API endpoint is not responding. Please try again or contact support if the issue persists.
                  </div>
                  <div className="flex gap-2 justify-center">
                    <div className="px-4 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs cursor-pointer">
                      Retry
                    </div>
                    <div className="px-4 py-2 border border-neutral-500 bg-white text-xs cursor-pointer">
                      Demo Mode
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 4: PERMISSION DENIED */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">Permission Denied State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Model Training</div>
              </div>
              
              {/* Permission denied content */}
              <div className="flex-1 p-6 bg-neutral-50 flex items-center justify-center">
                <div className="text-center max-w-md">
                  <Lock className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                  <div className="text-sm text-neutral-800 mb-2">Access Denied</div>
                  <div className="text-xs text-neutral-600 mb-4">
                    You don't have permission to access this page. Only Admin users can retrain the model. Contact your organization administrator to request access.
                  </div>
                  <div className="px-4 py-2 border border-neutral-700 bg-white text-xs inline-block cursor-pointer hover:bg-neutral-50">
                    Back to Dashboard
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 5: FIRST-TIME / ONBOARDING */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">First-Time Onboarding State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Dashboard</div>
              </div>
              
              {/* Onboarding content */}
              <div className="flex-1 p-6 bg-gradient-to-b from-neutral-50 to-neutral-100 flex items-center justify-center">
                <div className="text-center max-w-lg">
                  <div className="w-20 h-20 border-2 border-neutral-700 bg-neutral-200 rounded-full mx-auto mb-4 flex items-center justify-center text-2xl">
                    👋
                  </div>
                  <div className="text-lg text-neutral-900 mb-2">Welcome to Energy Monitor!</div>
                  <div className="text-xs text-neutral-700 mb-6">
                    Get started by connecting your first building's energy data. Once data starts flowing, 
                    our AI model will begin analyzing and predicting appliance usage.
                  </div>
                  
                  <div className="border-2 border-neutral-700 bg-white p-5 mb-4 text-left">
                    <div className="text-sm text-neutral-900 mb-3">Quick Start Steps:</div>
                    <div className="space-y-2 text-xs text-neutral-700">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">1</div>
                        <div>Add your first building</div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">2</div>
                        <div>Connect data source (API or CSV upload)</div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">3</div>
                        <div>Wait 24 hours for initial predictions</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 justify-center">
                    <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer">
                      Add Building
                    </div>
                    <div className="px-5 py-2.5 border border-neutral-500 bg-white text-sm cursor-pointer">
                      View Demo
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 6: LOADING SKELETON */}
          <div>
            <h2 className="text-sm mb-3 text-neutral-700">Loading Skeleton State</h2>
            <div className="w-[700px] h-[520px] bg-white border-4 border-neutral-900 overflow-hidden flex flex-col">
              {/* Top bar */}
              <div className="h-12 border-b-2 border-neutral-800 bg-neutral-50 flex items-center px-4">
                <div className="text-sm text-neutral-900">Dashboard</div>
              </div>
              
              {/* Skeleton content */}
              <div className="flex-1 p-6 bg-neutral-50 space-y-4 animate-pulse">
                {/* Skeleton cards */}
                <div className="grid grid-cols-4 gap-3">
                  <div className="h-20 bg-neutral-200 border border-neutral-400"></div>
                  <div className="h-20 bg-neutral-200 border border-neutral-400"></div>
                  <div className="h-20 bg-neutral-200 border border-neutral-400"></div>
                  <div className="h-20 bg-neutral-200 border border-neutral-400"></div>
                </div>
                
                {/* Skeleton chart */}
                <div className="h-48 bg-neutral-200 border border-neutral-400"></div>
                
                {/* Skeleton table */}
                <div className="space-y-2">
                  <div className="h-8 bg-neutral-200 border border-neutral-400"></div>
                  <div className="h-6 bg-neutral-100 border border-neutral-300"></div>
                  <div className="h-6 bg-neutral-100 border border-neutral-300"></div>
                  <div className="h-6 bg-neutral-100 border border-neutral-300"></div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        
        {/* Notes */}
        <div className="mt-8 bg-white border-2 border-neutral-700 p-6">
          <div className="text-sm text-neutral-900 mb-3">State Implementation Notes</div>
          <div className="space-y-2 text-xs text-neutral-700">
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Loading:</strong> Show spinner with message while fetching data. Disable interactive elements during load.</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Empty:</strong> Provide helpful guidance when no data exists. Suggest actionable next steps.</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Error:</strong> Clear error message with retry option. Provide fallback (Demo Mode) when available.</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Permission Denied:</strong> Explain access restrictions clearly. Provide contact information for access requests.</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Onboarding:</strong> Welcome new users with clear next steps. Make it easy to get started or explore demo.</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Skeleton:</strong> Show layout structure while loading. Maintains visual stability and reduces perceived latency.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
