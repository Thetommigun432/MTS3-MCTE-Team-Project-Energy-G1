export function Sitemap() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-2xl mb-6 text-neutral-800">Sitemap</div>
        
        <div className="bg-white border-4 border-neutral-900 p-12 inline-block">
          <div className="text-xs text-neutral-500 mb-6">Energy Monitor — Site Structure</div>
          
          {/* Tree structure */}
          <div className="space-y-2 text-xs">
            {/* Public Site */}
            <div className="mb-4">
              <div className="text-sm text-neutral-900 mb-2">PUBLIC SITE</div>
              <div className="ml-4 space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-40 px-3 py-2 border-2 border-neutral-800 bg-neutral-100">Home (/)</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-40 px-3 py-2 border-2 border-neutral-800 bg-neutral-100">About (/about)</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-40 px-3 py-2 border-2 border-neutral-800 bg-neutral-100">Docs (/docs)</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-40 px-3 py-2 border-2 border-neutral-800 bg-neutral-100">Contact (/contact)</div>
                </div>
              </div>
            </div>
            
            {/* Auth */}
            <div className="mb-4">
              <div className="text-sm text-neutral-900 mb-2">AUTHENTICATION</div>
              <div className="ml-4 space-y-1">
                <div className="w-48 px-3 py-2 border-2 border-neutral-800 bg-neutral-200">Login (/login)</div>
                <div className="w-48 px-3 py-2 border-2 border-neutral-800 bg-neutral-200">Sign Up (/signup)</div>
                <div className="w-56 px-3 py-2 border-2 border-neutral-800 bg-neutral-200">Forgot Password (/forgot-password)</div>
                <div className="w-52 px-3 py-2 border-2 border-neutral-800 bg-neutral-200">Verify Email (/verify-email)</div>
              </div>
            </div>
            
            {/* App */}
            <div>
              <div className="text-sm text-neutral-900 mb-2">APPLICATION (Authenticated)</div>
              <div className="ml-4 space-y-1">
                <div className="w-56 px-3 py-2 border-2 border-neutral-900 bg-neutral-300 font-semibold">
                  Dashboard (/app/dashboard)
                </div>
                <div className="w-64 px-3 py-2 border-2 border-neutral-800 bg-white">
                  Appliance Details (/app/appliances/:name)
                </div>
                
                <div className="mt-2">
                  <div className="w-56 px-3 py-2 border-2 border-neutral-800 bg-white">
                    Buildings (/app/buildings)
                  </div>
                  <div className="ml-8 mt-1">
                    <div className="w-64 px-3 py-2 border-2 border-neutral-800 bg-white">
                      Building Detail (/app/buildings/:id)
                    </div>
                  </div>
                </div>
                
                <div className="w-52 px-3 py-2 border-2 border-neutral-800 bg-white">
                  Reports (/app/reports)
                </div>
                <div className="w-48 px-3 py-2 border-2 border-neutral-800 bg-white">
                  Model (/app/model)
                </div>
                
                <div className="mt-2">
                  <div className="w-52 px-3 py-2 border-2 border-neutral-800 bg-white">
                    Settings
                  </div>
                  <div className="ml-8 mt-1 space-y-1">
                    <div className="w-64 px-3 py-2 border-2 border-neutral-800 bg-white">
                      Profile (/app/settings/profile)
                    </div>
                    <div className="w-64 px-3 py-2 border-2 border-neutral-800 bg-white">
                      Organization (/app/settings/org)
                    </div>
                    <div className="w-64 px-3 py-2 border-2 border-neutral-800 bg-white">
                      Users (/app/settings/users)
                    </div>
                  </div>
                </div>
                
                <div className="w-44 px-3 py-2 border-2 border-neutral-800 bg-white">
                  Help (/app/help)
                </div>
              </div>
            </div>
          </div>
          
          {/* Legend */}
          <div className="mt-8 pt-6 border-t border-neutral-400 space-y-2 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-16 px-2 py-1 border-2 border-neutral-900 bg-neutral-300"></div>
              <span className="text-neutral-700">= MVP / Primary page</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-16 px-2 py-1 border-2 border-neutral-800 bg-neutral-200"></div>
              <span className="text-neutral-700">= Auth pages</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-16 px-2 py-1 border-2 border-neutral-800 bg-neutral-100"></div>
              <span className="text-neutral-700">= Public pages</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-16 px-2 py-1 border-2 border-neutral-800 bg-white"></div>
              <span className="text-neutral-700">= App pages</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
