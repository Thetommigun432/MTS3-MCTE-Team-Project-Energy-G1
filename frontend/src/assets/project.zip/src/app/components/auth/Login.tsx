export function AuthLogin() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-sm text-neutral-600 mb-4">LOGIN (/login) — 1440×900</div>
        
        <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto flex items-center justify-center">
          <div className="w-full max-w-md">
            
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 border-2 border-neutral-700 bg-neutral-300 mx-auto mb-4"></div>
              <div className="text-xl text-neutral-900 mb-1">Energy Monitor</div>
              <div className="text-xs text-neutral-600">Sign in to your account</div>
            </div>
            
            {/* Login Form */}
            <div className="border-2 border-neutral-700 bg-white p-8">
              <div className="space-y-4">
                <div>
                  <div className="text-xs text-neutral-700 mb-2">Email</div>
                  <div className="border-2 border-neutral-600 bg-white px-3 py-2.5">
                    <div className="text-xs text-neutral-400">[email@example.com]</div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs text-neutral-700">Password</div>
                    <div className="text-xs text-neutral-600 underline cursor-pointer hover:text-neutral-900">
                      Forgot password?
                    </div>
                  </div>
                  <div className="border-2 border-neutral-600 bg-white px-3 py-2.5">
                    <div className="text-xs text-neutral-400">[••••••••]</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 pt-2">
                  <div className="w-4 h-4 border-2 border-neutral-600 bg-white"></div>
                  <div className="text-xs text-neutral-700">Remember me for 30 days</div>
                </div>
                
                <div className="pt-2">
                  <div className="w-full px-6 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm text-center cursor-pointer hover:bg-neutral-700">
                    Sign In
                  </div>
                </div>
              </div>
            </div>
            
            {/* Sign Up Link */}
            <div className="text-center mt-6 text-xs text-neutral-700">
              Don't have an account? 
              <span className="ml-1 text-neutral-900 underline cursor-pointer hover:text-neutral-700">Sign up</span>
            </div>
            
            {/* Divider */}
            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 border-t border-neutral-400"></div>
              <div className="text-xs text-neutral-500">OR</div>
              <div className="flex-1 border-t border-neutral-400"></div>
            </div>
            
            {/* SSO Options */}
            <div className="space-y-2">
              <div className="border-2 border-neutral-600 bg-white px-4 py-2.5 text-sm text-center cursor-pointer hover:bg-neutral-50 flex items-center justify-center gap-2">
                <div className="w-5 h-5 border border-neutral-500 bg-neutral-200"></div>
                <span>Continue with Google</span>
              </div>
              <div className="border-2 border-neutral-600 bg-white px-4 py-2.5 text-sm text-center cursor-pointer hover:bg-neutral-50 flex items-center justify-center gap-2">
                <div className="w-5 h-5 border border-neutral-500 bg-neutral-200"></div>
                <span>Continue with GitHub</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
