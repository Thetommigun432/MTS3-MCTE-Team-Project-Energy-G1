import { useState } from 'react';
import { CheckCircle } from 'lucide-react';

export function AuthForgotPassword() {
  const [sent, setSent] = useState(false);
  
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-sm text-neutral-600 mb-4">FORGOT PASSWORD (/forgot-password) — 1440×900</div>
        
        <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto flex items-center justify-center">
          
          {!sent ? (
            // Initial state: Email input
            <div className="w-full max-w-md">
              <div className="text-center mb-8">
                <div className="w-16 h-16 border-2 border-neutral-700 bg-neutral-300 mx-auto mb-4"></div>
                <div className="text-xl text-neutral-900 mb-2">Forgot Password?</div>
                <div className="text-xs text-neutral-600 max-w-sm mx-auto">
                  Enter your email and we'll send you instructions to reset your password
                </div>
              </div>
              
              <div className="border-2 border-neutral-700 bg-white p-8">
                <div className="space-y-4">
                  <div>
                    <div className="text-xs text-neutral-700 mb-2">Email</div>
                    <div className="border-2 border-neutral-600 bg-white px-3 py-2.5">
                      <div className="text-xs text-neutral-400">[email@example.com]</div>
                    </div>
                  </div>
                  
                  <div className="pt-2">
                    <div 
                      onClick={() => setSent(true)}
                      className="w-full px-6 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm text-center cursor-pointer hover:bg-neutral-700"
                    >
                      Send Reset Link
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-center mt-6 text-xs text-neutral-700">
                Remember your password? 
                <span className="ml-1 text-neutral-900 underline cursor-pointer hover:text-neutral-700">Sign in</span>
              </div>
            </div>
          ) : (
            // Confirmation state
            <div className="w-full max-w-md text-center">
              <CheckCircle className="w-16 h-16 mx-auto mb-6 text-neutral-700 border-2 border-neutral-700 rounded-full p-3" />
              <div className="text-xl text-neutral-900 mb-3">Check your email</div>
              <div className="text-sm text-neutral-700 mb-6 max-w-sm mx-auto">
                We've sent password reset instructions to <strong>email@example.com</strong>
              </div>
              
              <div className="border-2 border-neutral-400 bg-neutral-50 p-6 max-w-sm mx-auto mb-6">
                <div className="text-xs text-neutral-700 mb-3">
                  Didn't receive the email?
                </div>
                <div className="px-4 py-2 border border-neutral-700 bg-white text-sm cursor-pointer hover:bg-neutral-50 inline-block">
                  Resend Email
                </div>
              </div>
              
              <div className="text-xs text-neutral-700">
                <span className="text-neutral-900 underline cursor-pointer hover:text-neutral-700">Back to login</span>
              </div>
            </div>
          )}
        </div>
        
        {/* Toggle button for wireframe demo */}
        <div className="text-center mt-4">
          <button 
            onClick={() => setSent(!sent)}
            className="px-4 py-2 bg-neutral-600 text-white text-xs"
          >
            Toggle State (Wireframe Demo)
          </button>
        </div>
      </div>
    </div>
  );
}
