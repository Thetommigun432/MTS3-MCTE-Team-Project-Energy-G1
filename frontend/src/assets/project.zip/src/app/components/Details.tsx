import { Menu, ChevronDown, ChevronLeft } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Demo data
const applianceData = [
  { time: '00:00', kW: 0.5 },
  { time: '03:00', kW: 0.5 },
  { time: '06:00', kW: 0.5 },
  { time: '09:00', kW: 0.5 },
  { time: '12:00', kW: 0.5 },
  { time: '15:00', kW: 0.5 },
  { time: '18:00', kW: 0.5 },
  { time: '21:00', kW: 0.5 },
];

export function Details() {
  return (
    <div className="bg-neutral-100">
      <div className="p-8 space-y-12">
        
        {/* DESKTOP FRAME - 1440x900 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Appliance Details – Desktop (1440×900)</h2>
          <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto">
            
            {/* Top Navigation */}
            <div className="h-16 border-b-2 border-neutral-800 flex items-center px-8 bg-neutral-200">
              <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
              <div className="text-lg text-neutral-800">Energy Monitor</div>
              <div className="ml-auto flex gap-8 text-sm text-neutral-700">
                <div>Home</div>
                <div>Dashboard</div>
                <div className="underline">Details</div>
              </div>
            </div>
            
            {/* Header Area */}
            <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
              <div className="flex items-center gap-3 mb-4">
                <ChevronLeft className="w-5 h-5 text-neutral-700" />
                <div className="text-xs text-neutral-700 underline">Back to Dashboard</div>
              </div>
              
              <div className="text-xl text-neutral-900 mb-4">Appliance Details</div>
              
              {/* Controls */}
              <div className="flex gap-3">
                <div className="flex-1">
                  <div className="text-xs text-neutral-700 mb-1">Select Appliance</div>
                  <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                    <span className="text-xs">Refrigerator</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="text-xs text-neutral-700 mb-1">Date Range</div>
                  <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                    <span className="text-xs">Jan 1 – Jan 7, 2026</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>
                
                <div className="flex items-end gap-2">
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">Today</div>
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">7 days</div>
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">30 days</div>
                </div>
                
                <div className="flex items-end">
                  <div className="px-6 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs">
                    Apply
                  </div>
                </div>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="p-8 space-y-6">
              
              {/* Summary Stats */}
              <div className="grid grid-cols-4 gap-4">
                <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                  <div className="text-xs text-neutral-600 mb-2">Current Status</div>
                  <div className="text-2xl text-neutral-900">ON</div>
                  <div className="text-xs text-neutral-500 mt-1">78% confidence</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                  <div className="text-xs text-neutral-600 mb-2">Current Draw</div>
                  <div className="text-2xl text-neutral-900">0.5 kW</div>
                  <div className="text-xs text-neutral-500 mt-1">Estimated</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                  <div className="text-xs text-neutral-600 mb-2">Total Energy (7d)</div>
                  <div className="text-2xl text-neutral-900">84 kWh</div>
                  <div className="text-xs text-neutral-500 mt-1">Jan 1-7</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                  <div className="text-xs text-neutral-600 mb-2">Avg Runtime</div>
                  <div className="text-2xl text-neutral-900">24 hrs</div>
                  <div className="text-xs text-neutral-500 mt-1">Always on</div>
                </div>
              </div>
              
              {/* Chart: Appliance Estimated kW */}
              <div className="border-2 border-neutral-700 bg-white p-4">
                <div className="text-sm text-neutral-900 mb-3">Estimated Power Consumption (kW)</div>
                <div className="h-64 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={applianceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 10, fill: '#525252' }} label={{ value: 'kW', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                      <Tooltip contentStyle={{ fontSize: 10, backgroundColor: '#f5f5f5' }} />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                      <Line type="monotone" dataKey="kW" stroke="#404040" strokeWidth={2} dot={{ fill: '#404040', r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-xs text-neutral-500 mt-2">Refrigerator | 15-minute resolution | Time axis: UTC</div>
              </div>
              
              {/* ON/OFF Timeline */}
              <div className="border-2 border-neutral-700 bg-white p-4">
                <div className="text-sm text-neutral-900 mb-3">ON/OFF Timeline</div>
                <div className="bg-neutral-50 border border-neutral-400 p-4">
                  {/* Timeline strip */}
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 1</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 2</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 3</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 4</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 5</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 6</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-xs text-neutral-600 w-16">Jan 7</div>
                    <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  
                  {/* Legend */}
                  <div className="flex gap-4 mt-4 text-xs text-neutral-700">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-4 bg-neutral-800 border border-neutral-900"></div>
                      <span>ON</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-4 border border-neutral-600 bg-neutral-200"></div>
                      <span>OFF</span>
                    </div>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mt-2">Refrigerator typically runs continuously</div>
              </div>
              
              {/* Top Usage Periods Table */}
              <div className="border-2 border-neutral-700 bg-white">
                <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
                  <div className="text-sm text-neutral-900">Top Usage Periods</div>
                  <div className="text-xs text-neutral-500">Highest estimated energy consumption intervals</div>
                </div>
                
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-neutral-400 bg-neutral-100">
                      <th className="text-left px-4 py-2 text-neutral-700">Date / Time</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Duration</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Estimated kWh</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Confidence</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Jan 7, 00:00 – 23:45</td>
                      <td className="px-4 py-2">24 hours</td>
                      <td className="px-4 py-2">12.0</td>
                      <td className="px-4 py-2">78%</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Jan 6, 00:00 – 23:45</td>
                      <td className="px-4 py-2">24 hours</td>
                      <td className="px-4 py-2">12.0</td>
                      <td className="px-4 py-2">79%</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Jan 5, 00:00 – 23:45</td>
                      <td className="px-4 py-2">24 hours</td>
                      <td className="px-4 py-2">12.0</td>
                      <td className="px-4 py-2">77%</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Jan 4, 00:00 – 23:45</td>
                      <td className="px-4 py-2">24 hours</td>
                      <td className="px-4 py-2">12.0</td>
                      <td className="px-4 py-2">80%</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Jan 3, 00:00 – 23:45</td>
                      <td className="px-4 py-2">24 hours</td>
                      <td className="px-4 py-2">12.0</td>
                      <td className="px-4 py-2">76%</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        {/* MOBILE FRAME - 390x844 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Appliance Details – Mobile (390×844)</h2>
          <div className="w-[390px] h-[844px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto">
            
            {/* Top Navigation */}
            <div className="h-14 border-b-2 border-neutral-800 flex items-center px-4 bg-neutral-200 justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 border-2 border-neutral-700 bg-neutral-300"></div>
                <div className="text-sm text-neutral-800">Energy Monitor</div>
              </div>
              <Menu className="w-6 h-6 text-neutral-800" />
            </div>
            
            {/* Header Area */}
            <div className="border-b-2 border-neutral-400 px-4 py-3 bg-neutral-50">
              <div className="flex items-center gap-2 mb-3">
                <ChevronLeft className="w-4 h-4 text-neutral-700" />
                <div className="text-[10px] text-neutral-700 underline">Back to Dashboard</div>
              </div>
              
              <div className="text-base text-neutral-900 mb-3">Appliance Details</div>
              
              {/* Controls - Stacked */}
              <div className="space-y-2">
                <div>
                  <div className="text-[10px] text-neutral-700 mb-1">Select Appliance</div>
                  <div className="border-2 border-neutral-700 bg-white px-2 py-1.5 flex items-center justify-between text-xs">
                    <span>Refrigerator</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </div>
                
                <div>
                  <div className="text-[10px] text-neutral-700 mb-1">Date Range</div>
                  <div className="border-2 border-neutral-700 bg-white px-2 py-1.5 flex items-center justify-between text-xs">
                    <span>Jan 1 – Jan 7, 2026</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">Today</div>
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">7 days</div>
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">30 days</div>
                </div>
                
                <div className="px-4 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs text-center">
                  Apply
                </div>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="p-4 space-y-4">
              
              {/* Summary Stats - Single Column */}
              <div className="space-y-2">
                <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                  <div className="text-[10px] text-neutral-600 mb-1">Current Status</div>
                  <div className="text-xl text-neutral-900">ON</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">78% confidence</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                  <div className="text-[10px] text-neutral-600 mb-1">Current Draw</div>
                  <div className="text-xl text-neutral-900">0.5 kW</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Estimated</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                  <div className="text-[10px] text-neutral-600 mb-1">Total Energy (7d)</div>
                  <div className="text-xl text-neutral-900">84 kWh</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Jan 1-7</div>
                </div>
                
                <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                  <div className="text-[10px] text-neutral-600 mb-1">Avg Runtime</div>
                  <div className="text-xl text-neutral-900">24 hrs</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Always on</div>
                </div>
              </div>
              
              {/* Chart */}
              <div className="border-2 border-neutral-700 bg-white p-3">
                <div className="text-xs text-neutral-900 mb-2">Estimated Power (kW)</div>
                <div className="h-32 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={applianceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 8, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 8, fill: '#525252' }} />
                      <Tooltip contentStyle={{ fontSize: 8, backgroundColor: '#f5f5f5' }} />
                      <Line type="monotone" dataKey="kW" stroke="#404040" strokeWidth={1.5} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-[10px] text-neutral-500 mt-1">Refrigerator | 15-min</div>
              </div>
              
              {/* ON/OFF Timeline */}
              <div className="border-2 border-neutral-700 bg-white p-3">
                <div className="text-xs text-neutral-900 mb-2">ON/OFF Timeline</div>
                <div className="bg-neutral-50 border border-neutral-400 p-2 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 1</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 2</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 3</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 4</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 5</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 6</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-[10px] text-neutral-600 w-10">Jan 7</div>
                    <div className="flex-1 h-6 bg-neutral-800 border border-neutral-900"></div>
                  </div>
                  
                  <div className="flex gap-3 mt-2 text-[10px] text-neutral-700">
                    <div className="flex items-center gap-1">
                      <div className="w-4 h-3 bg-neutral-800 border border-neutral-900"></div>
                      <span>ON</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-4 h-3 border border-neutral-600 bg-neutral-200"></div>
                      <span>OFF</span>
                    </div>
                  </div>
                </div>
                <div className="text-[10px] text-neutral-500 mt-1">Runs continuously</div>
              </div>
              
              {/* Top Usage Periods */}
              <div className="border-2 border-neutral-700 bg-white">
                <div className="px-3 py-2 border-b border-neutral-400 bg-neutral-50">
                  <div className="text-xs text-neutral-900">Top Usage Periods</div>
                  <div className="text-[10px] text-neutral-500">Highest consumption</div>
                </div>
                
                <div className="divide-y divide-neutral-300">
                  <div className="px-3 py-2 text-[10px]">
                    <div className="text-neutral-900">Jan 7, 00:00 – 23:45</div>
                    <div className="text-neutral-600 mt-0.5">24h | 12.0 kWh | 78% conf.</div>
                  </div>
                  <div className="px-3 py-2 text-[10px]">
                    <div className="text-neutral-900">Jan 6, 00:00 – 23:45</div>
                    <div className="text-neutral-600 mt-0.5">24h | 12.0 kWh | 79% conf.</div>
                  </div>
                  <div className="px-3 py-2 text-[10px]">
                    <div className="text-neutral-900">Jan 5, 00:00 – 23:45</div>
                    <div className="text-neutral-600 mt-0.5">24h | 12.0 kWh | 77% conf.</div>
                  </div>
                  <div className="px-3 py-2 text-[10px]">
                    <div className="text-neutral-900">Jan 4, 00:00 – 23:45</div>
                    <div className="text-neutral-600 mt-0.5">24h | 12.0 kWh | 80% conf.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
