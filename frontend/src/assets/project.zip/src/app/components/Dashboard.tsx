import { Menu, ChevronDown } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Demo data
const totalConsumptionData = [
  { time: '00:00', kW: 2.1 },
  { time: '03:00', kW: 1.8 },
  { time: '06:00', kW: 3.2 },
  { time: '09:00', kW: 4.5 },
  { time: '12:00', kW: 5.2 },
  { time: '15:00', kW: 4.8 },
  { time: '18:00', kW: 6.1 },
  { time: '21:00', kW: 3.9 },
];

const disaggregationData = [
  { time: '00:00', hvac: 1.2, refrigerator: 0.5, lighting: 0.2, dishwasher: 0, waterHeater: 0.2 },
  { time: '03:00', hvac: 1.0, refrigerator: 0.5, lighting: 0.1, dishwasher: 0, waterHeater: 0.2 },
  { time: '06:00', hvac: 1.5, refrigerator: 0.5, lighting: 0.4, dishwasher: 0.6, waterHeater: 0.2 },
  { time: '09:00', hvac: 2.0, refrigerator: 0.5, lighting: 0.6, dishwasher: 1.2, waterHeater: 0.2 },
  { time: '12:00', hvac: 2.2, refrigerator: 0.5, lighting: 0.8, dishwasher: 1.5, waterHeater: 0.2 },
  { time: '15:00', hvac: 2.0, refrigerator: 0.5, lighting: 0.6, dishwasher: 1.5, waterHeater: 0.2 },
  { time: '18:00', hvac: 2.5, refrigerator: 0.5, lighting: 1.0, dishwasher: 1.8, waterHeater: 0.3 },
  { time: '21:00', hvac: 1.8, refrigerator: 0.5, lighting: 0.8, dishwasher: 0.6, waterHeater: 0.2 },
];

export function Dashboard() {
  return (
    <div className="bg-neutral-100">
      <div className="p-8 space-y-12">
        
        {/* DESKTOP FRAME - 1440x900 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Dashboard – Desktop (1440×900)</h2>
          <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto">
            
            {/* Top Navigation */}
            <div className="h-16 border-b-2 border-neutral-800 flex items-center px-8 bg-neutral-200">
              <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
              <div className="text-lg text-neutral-800">Energy Monitor</div>
              <div className="ml-auto flex gap-8 text-sm text-neutral-700">
                <div>Home</div>
                <div className="underline">Dashboard</div>
                <div>Details</div>
              </div>
            </div>
            
            {/* Header Area */}
            <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="text-xl text-neutral-900">Dashboard</div>
                  <div className="text-xs text-neutral-500 mt-1">Last updated: Jan 7, 2026 14:23 UTC</div>
                </div>
                
                {/* Mode Toggle */}
                <div className="flex items-center gap-3 border-2 border-neutral-700 bg-white">
                  <div className="px-4 py-2 bg-neutral-800 text-white text-xs">Demo Mode</div>
                  <div className="px-4 py-2 text-xs text-neutral-600">API Mode</div>
                </div>
              </div>
              
              <div className="text-xs text-neutral-600 mb-4">
                Using local demo data
              </div>
              
              {/* Global Controls */}
              <div className="text-xs text-neutral-500 mb-2">Filters affect all panels below ↓</div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <div className="text-xs text-neutral-700 mb-1">Building</div>
                  <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                    <span className="text-xs">Building A</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="text-xs text-neutral-700 mb-1">Date Range</div>
                  <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                    <span className="text-xs">Jan 1 – Jan 7, 2026</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>
                
                <div className="flex items-end gap-2">
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">Today</div>
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">7 days</div>
                  <div className="px-2 py-1.5 border border-neutral-500 bg-neutral-100 text-xs">30 days</div>
                </div>
                
                <div className="flex-1">
                  <div className="text-xs text-neutral-700 mb-1">Appliance (optional)</div>
                  <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                    <span className="text-xs text-neutral-500">All appliances</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </div>
                
                <div className="flex items-end">
                  <div className="px-6 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs">
                    Apply
                  </div>
                </div>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="p-8 space-y-6">
              
              {/* At a Glance Cards - 2x2 Grid */}
              <div>
                <div className="text-sm text-neutral-900 mb-3">At a glance</div>
                <div className="grid grid-cols-4 gap-4">
                  
                  {/* Card 1 */}
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                    <div className="text-xs text-neutral-600 mb-2">Peak Load</div>
                    <div className="text-2xl text-neutral-900">6.1 kW</div>
                    <div className="text-xs text-neutral-500 mt-1">@ 18:00, Jan 7</div>
                  </div>
                  
                  {/* Card 2 */}
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                    <div className="text-xs text-neutral-600 mb-2">Total Energy</div>
                    <div className="text-2xl text-neutral-900">285 kWh</div>
                    <div className="text-xs text-neutral-500 mt-1">7-day period</div>
                  </div>
                  
                  {/* Card 3 */}
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                    <div className="text-xs text-neutral-600 mb-2">Top Predicted Appliance</div>
                    <div className="text-2xl text-neutral-900">HVAC</div>
                    <div className="text-xs text-neutral-500 mt-1">92% confidence</div>
                  </div>
                  
                  {/* Card 4 */}
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-4">
                    <div className="text-xs text-neutral-600 mb-2">Model Confidence</div>
                    <div className="text-2xl text-neutral-900">Good</div>
                    <div className="text-xs text-neutral-500 mt-1">Avg 87%</div>
                  </div>
                </div>
              </div>
              
              {/* Chart 1: Total Consumption */}
              <div className="border-2 border-neutral-700 bg-white p-4">
                <div className="text-sm text-neutral-900 mb-3">Total Consumption (kW)</div>
                <div className="h-48 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={totalConsumptionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 10, fill: '#525252' }} label={{ value: 'kW', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                      <Tooltip contentStyle={{ fontSize: 10, backgroundColor: '#f5f5f5' }} />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                      <Line type="monotone" dataKey="kW" stroke="#404040" strokeWidth={2} dot={{ fill: '#404040', r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-xs text-neutral-500 mt-2">15-minute resolution | Time axis: UTC</div>
              </div>
              
              {/* Chart 2: Disaggregation Summary */}
              <div className="border-2 border-neutral-700 bg-white p-4">
                <div className="text-sm text-neutral-900 mb-3">Disaggregation Summary – Estimated by AI (kW)</div>
                <div className="h-48 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={disaggregationData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 10, fill: '#525252' }} label={{ value: 'kW', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                      <Tooltip contentStyle={{ fontSize: 10, backgroundColor: '#f5f5f5' }} />
                      <Legend wrapperStyle={{ fontSize: 10 }} />
                      <Area type="monotone" dataKey="hvac" stackId="1" stroke="#171717" fill="#737373" />
                      <Area type="monotone" dataKey="dishwasher" stackId="1" stroke="#171717" fill="#a3a3a3" />
                      <Area type="monotone" dataKey="lighting" stackId="1" stroke="#171717" fill="#d4d4d4" />
                      <Area type="monotone" dataKey="refrigerator" stackId="1" stroke="#171717" fill="#e5e5e5" />
                      <Area type="monotone" dataKey="waterHeater" stackId="1" stroke="#171717" fill="#f5f5f5" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-xs text-neutral-500 mt-2">Top 5 appliances by estimated kW | Stacked view</div>
              </div>
              
              {/* Appliance Status Table */}
              <div className="border-2 border-neutral-700 bg-white">
                <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
                  <div className="text-sm text-neutral-900">Appliance Status</div>
                  <div className="text-xs text-neutral-500">Current predicted state (sorted by confidence)</div>
                </div>
                
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-neutral-400 bg-neutral-100">
                      <th className="text-left px-4 py-2 text-neutral-700">Appliance Name</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Predicted State</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Confidence %</th>
                      <th className="text-left px-4 py-2 text-neutral-700">Estimated kW (now)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">HVAC</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 bg-neutral-800 text-white">ON</span>
                      </td>
                      <td className="px-4 py-2">92%</td>
                      <td className="px-4 py-2">2.5</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Dishwasher</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 bg-neutral-800 text-white">ON</span>
                      </td>
                      <td className="px-4 py-2">88%</td>
                      <td className="px-4 py-2">1.8</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Lighting</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 bg-neutral-800 text-white">ON</span>
                      </td>
                      <td className="px-4 py-2">85%</td>
                      <td className="px-4 py-2">1.0</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Refrigerator</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 bg-neutral-800 text-white">ON</span>
                      </td>
                      <td className="px-4 py-2">78%</td>
                      <td className="px-4 py-2">0.5</td>
                    </tr>
                    <tr className="border-b border-neutral-300">
                      <td className="px-4 py-2">Water Heater</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 border border-neutral-600 bg-neutral-200">OFF</span>
                      </td>
                      <td className="px-4 py-2">65%</td>
                      <td className="px-4 py-2">0.0</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Washing Machine</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-0.5 border border-neutral-600 bg-neutral-200">OFF</span>
                      </td>
                      <td className="px-4 py-2">72%</td>
                      <td className="px-4 py-2">0.0</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              {/* Secondary Actions */}
              <div className="flex gap-4 text-xs">
                <div className="px-4 py-2 border-2 border-neutral-700 bg-white underline cursor-pointer">
                  View Appliance Details →
                </div>
                <div className="px-4 py-2 border border-neutral-500 bg-neutral-100 text-neutral-600">
                  Export (CSV)
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* MOBILE FRAME - 390x844 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Dashboard – Mobile (390×844)</h2>
          <div className="w-[390px] h-[844px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto">
            
            {/* Top Navigation */}
            <div className="h-14 border-b-2 border-neutral-800 flex items-center px-4 bg-neutral-200 justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 border-2 border-neutral-700 bg-neutral-300"></div>
                <div className="text-sm text-neutral-800">Energy Monitor</div>
              </div>
              <Menu className="w-6 h-6 text-neutral-800" />
            </div>
            
            {/* Header Area */}
            <div className="border-b-2 border-neutral-400 px-4 py-3 bg-neutral-50">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-base text-neutral-900">Dashboard</div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Last updated: Jan 7, 14:23</div>
                </div>
                
                {/* Mode Toggle */}
                <div className="flex border border-neutral-700 bg-white text-[10px]">
                  <div className="px-2 py-1 bg-neutral-800 text-white">Demo</div>
                  <div className="px-2 py-1 text-neutral-600">API</div>
                </div>
              </div>
              
              <div className="text-[10px] text-neutral-600 mb-3">Using local demo data</div>
              
              {/* Global Controls - Stacked */}
              <div className="text-[10px] text-neutral-500 mb-2">Filters affect all panels ↓</div>
              <div className="space-y-2">
                <div>
                  <div className="text-[10px] text-neutral-700 mb-1">Building</div>
                  <div className="border-2 border-neutral-700 bg-white px-2 py-1.5 flex items-center justify-between text-xs">
                    <span>Building A</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </div>
                
                <div>
                  <div className="text-[10px] text-neutral-700 mb-1">Date Range</div>
                  <div className="border-2 border-neutral-700 bg-white px-2 py-1.5 flex items-center justify-between text-xs">
                    <span>Jan 1 – Jan 7, 2026</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">Today</div>
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">7 days</div>
                  <div className="flex-1 px-2 py-1 border border-neutral-500 bg-neutral-100 text-[10px] text-center">30 days</div>
                </div>
                
                <div>
                  <div className="text-[10px] text-neutral-700 mb-1">Appliance</div>
                  <div className="border-2 border-neutral-700 bg-white px-2 py-1.5 flex items-center justify-between text-xs">
                    <span className="text-neutral-500">All appliances</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </div>
                
                <div className="px-4 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs text-center">
                  Apply
                </div>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="p-4 space-y-4">
              
              {/* At a Glance Cards - Single Column */}
              <div>
                <div className="text-xs text-neutral-900 mb-2">At a glance</div>
                <div className="space-y-2">
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                    <div className="text-[10px] text-neutral-600 mb-1">Peak Load</div>
                    <div className="text-xl text-neutral-900">6.1 kW</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">@ 18:00, Jan 7</div>
                  </div>
                  
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                    <div className="text-[10px] text-neutral-600 mb-1">Total Energy</div>
                    <div className="text-xl text-neutral-900">285 kWh</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">7-day period</div>
                  </div>
                  
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                    <div className="text-[10px] text-neutral-600 mb-1">Top Predicted Appliance</div>
                    <div className="text-xl text-neutral-900">HVAC</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">92% confidence</div>
                  </div>
                  
                  <div className="border-2 border-neutral-700 bg-neutral-50 p-3">
                    <div className="text-[10px] text-neutral-600 mb-1">Model Confidence</div>
                    <div className="text-xl text-neutral-900">Good</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">Avg 87%</div>
                  </div>
                </div>
              </div>
              
              {/* Chart 1: Total Consumption */}
              <div className="border-2 border-neutral-700 bg-white p-3">
                <div className="text-xs text-neutral-900 mb-2">Total Consumption (kW)</div>
                <div className="h-32 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={totalConsumptionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 8, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 8, fill: '#525252' }} />
                      <Tooltip contentStyle={{ fontSize: 8, backgroundColor: '#f5f5f5' }} />
                      <Line type="monotone" dataKey="kW" stroke="#404040" strokeWidth={1.5} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-[10px] text-neutral-500 mt-1">15-min resolution</div>
              </div>
              
              {/* Chart 2: Disaggregation */}
              <div className="border-2 border-neutral-700 bg-white p-3">
                <div className="text-xs text-neutral-900 mb-2">Disaggregation – Est. by AI (kW)</div>
                <div className="h-32 bg-neutral-50 border border-neutral-400">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={disaggregationData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                      <XAxis dataKey="time" tick={{ fontSize: 8, fill: '#525252' }} />
                      <YAxis tick={{ fontSize: 8, fill: '#525252' }} />
                      <Tooltip contentStyle={{ fontSize: 8, backgroundColor: '#f5f5f5' }} />
                      <Area type="monotone" dataKey="hvac" stackId="1" stroke="#171717" fill="#737373" />
                      <Area type="monotone" dataKey="dishwasher" stackId="1" stroke="#171717" fill="#a3a3a3" />
                      <Area type="monotone" dataKey="lighting" stackId="1" stroke="#171717" fill="#d4d4d4" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-[10px] text-neutral-500 mt-1">Top 3 appliances</div>
              </div>
              
              {/* Appliance Status Table */}
              <div className="border-2 border-neutral-700 bg-white">
                <div className="px-3 py-2 border-b border-neutral-400 bg-neutral-50">
                  <div className="text-xs text-neutral-900">Appliance Status</div>
                  <div className="text-[10px] text-neutral-500">Current predicted state</div>
                </div>
                
                <div className="divide-y divide-neutral-300">
                  <div className="px-3 py-2 flex items-center justify-between text-[10px]">
                    <div className="flex-1">
                      <div className="text-neutral-900">HVAC</div>
                      <div className="text-neutral-600">92% conf. | 2.5 kW</div>
                    </div>
                    <div className="px-2 py-0.5 bg-neutral-800 text-white">ON</div>
                  </div>
                  
                  <div className="px-3 py-2 flex items-center justify-between text-[10px]">
                    <div className="flex-1">
                      <div className="text-neutral-900">Dishwasher</div>
                      <div className="text-neutral-600">88% conf. | 1.8 kW</div>
                    </div>
                    <div className="px-2 py-0.5 bg-neutral-800 text-white">ON</div>
                  </div>
                  
                  <div className="px-3 py-2 flex items-center justify-between text-[10px]">
                    <div className="flex-1">
                      <div className="text-neutral-900">Lighting</div>
                      <div className="text-neutral-600">85% conf. | 1.0 kW</div>
                    </div>
                    <div className="px-2 py-0.5 bg-neutral-800 text-white">ON</div>
                  </div>
                  
                  <div className="px-3 py-2 flex items-center justify-between text-[10px]">
                    <div className="flex-1">
                      <div className="text-neutral-900">Refrigerator</div>
                      <div className="text-neutral-600">78% conf. | 0.5 kW</div>
                    </div>
                    <div className="px-2 py-0.5 bg-neutral-800 text-white">ON</div>
                  </div>
                  
                  <div className="px-3 py-2 flex items-center justify-between text-[10px]">
                    <div className="flex-1">
                      <div className="text-neutral-900">Water Heater</div>
                      <div className="text-neutral-600">65% conf. | 0.0 kW</div>
                    </div>
                    <div className="px-2 py-0.5 border border-neutral-600 bg-neutral-200">OFF</div>
                  </div>
                </div>
              </div>
              
              {/* Secondary Actions */}
              <div className="space-y-2 text-xs">
                <div className="px-3 py-2 border-2 border-neutral-700 bg-white text-center underline">
                  View Appliance Details →
                </div>
                <div className="px-3 py-2 border border-neutral-500 bg-neutral-100 text-neutral-600 text-center">
                  Export (CSV)
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
