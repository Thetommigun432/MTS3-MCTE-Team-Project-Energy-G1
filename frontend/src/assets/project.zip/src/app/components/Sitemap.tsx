export function Sitemap() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl mb-8 text-neutral-800">Sitemap</h1>
        
        {/* Sitemap Frame */}
        <div className="bg-white border-4 border-neutral-900 p-8 inline-block">
          <div className="text-xs text-neutral-500 mb-4">Energy Monitor – Sitemap</div>
          
          {/* Tree structure */}
          <div className="space-y-4">
            {/* Root */}
            <div className="flex items-start gap-4">
              <div className="w-40 h-12 border-2 border-neutral-800 bg-neutral-100 flex items-center justify-center">
                <span className="text-sm">Home (/)</span>
              </div>
            </div>
            
            {/* Connector */}
            <div className="ml-20 border-l-2 border-neutral-400 h-4"></div>
            
            {/* Level 1 - Dashboard */}
            <div className="ml-20 flex items-start gap-4">
              <div className="w-48 h-12 border-2 border-neutral-800 bg-neutral-300 flex items-center justify-center">
                <span className="text-sm">Dashboard (/dashboard)</span>
              </div>
              <div className="text-xs text-neutral-600 self-center">← MVP page</div>
            </div>
            
            {/* Connector */}
            <div className="ml-40 border-l-2 border-neutral-400 h-4"></div>
            
            {/* Level 2 - Details */}
            <div className="ml-40 flex items-start gap-4">
              <div className="w-56 h-12 border-2 border-neutral-800 bg-neutral-100 flex items-center justify-center">
                <span className="text-sm">Appliance Details (/details)</span>
              </div>
              <div className="text-xs text-neutral-600 self-center">← Drill-down</div>
            </div>
          </div>
          
          {/* Legend */}
          <div className="mt-8 pt-4 border-t border-neutral-300 space-y-2 text-xs text-neutral-700">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 border-2 border-neutral-800 bg-neutral-300"></div>
              <span>= Primary page</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 border-2 border-neutral-800 bg-neutral-100"></div>
              <span>= Secondary page</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
