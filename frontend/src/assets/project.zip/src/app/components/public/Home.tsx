import { PublicLayout } from '../layouts/PublicLayout';
import { ArrowRight, Zap, BarChart3, Brain } from 'lucide-react';

export function PublicHome() {
  return (
    <PublicLayout title="HOME (/)">
      {/* Hero Section */}
      <div className="border-b-2 border-neutral-400 bg-neutral-50 py-20">
        <div className="max-w-4xl mx-auto text-center px-8">
          <div className="text-4xl text-neutral-900 mb-4">Energy Monitor</div>
          <div className="text-lg text-neutral-700 mb-2">AI-Powered Energy Disaggregation (NILM)</div>
          <div className="text-sm text-neutral-600 max-w-2xl mx-auto mb-8">
            Identify which appliances are running from just your building's total energy consumption. 
            No individual sensors needed—AI does the work.
          </div>
          <div className="flex gap-4 justify-center">
            <div className="px-6 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm flex items-center gap-2 cursor-pointer hover:bg-neutral-700">
              Get Started <ArrowRight className="w-4 h-4" />
            </div>
            <div className="px-6 py-3 border-2 border-neutral-700 bg-white text-sm cursor-pointer hover:bg-neutral-50">
              View Demo
            </div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-16 px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="text-2xl text-neutral-900 mb-2">How It Works</div>
            <div className="text-sm text-neutral-600">Three simple steps to appliance-level insights</div>
          </div>
          
          <div className="grid grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="w-12 h-12 border-2 border-neutral-800 bg-neutral-200 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-neutral-700" />
              </div>
              <div className="text-base text-neutral-900 mb-2">1. Connect Data Source</div>
              <div className="text-xs text-neutral-700 leading-relaxed">
                Send us your building's total energy consumption time-series (15-min intervals, kW). 
                We support API, CSV upload, or direct meter integration.
              </div>
            </div>
            
            {/* Feature 2 */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="w-12 h-12 border-2 border-neutral-800 bg-neutral-200 flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-neutral-700" />
              </div>
              <div className="text-base text-neutral-900 mb-2">2. AI Analyzes Patterns</div>
              <div className="text-xs text-neutral-700 leading-relaxed">
                Our NILM model identifies unique electrical signatures of appliances (HVAC, dishwasher, lighting, etc.) 
                from the aggregate signal.
              </div>
            </div>
            
            {/* Feature 3 */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="w-12 h-12 border-2 border-neutral-800 bg-neutral-200 flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-neutral-700" />
              </div>
              <div className="text-base text-neutral-900 mb-2">3. View Insights Dashboard</div>
              <div className="text-xs text-neutral-700 leading-relaxed">
                See real-time appliance ON/OFF predictions, estimated kW per device, confidence scores, 
                and historical trends—all in one place.
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Benefits Section */}
      <div className="border-t-2 border-neutral-400 bg-neutral-50 py-16 px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-2xl text-neutral-900 mb-8 text-center">Key Benefits</div>
          
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3 border-l-4 border-neutral-800 pl-4 py-2">
              <div className="w-6 h-6 border border-neutral-700 bg-neutral-200 shrink-0 flex items-center justify-center text-xs">✓</div>
              <div>
                <div className="text-neutral-900 mb-1">No Hardware Installation</div>
                <div className="text-xs text-neutral-600">No need for individual smart plugs or sub-meters</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 border-l-4 border-neutral-800 pl-4 py-2">
              <div className="w-6 h-6 border border-neutral-700 bg-neutral-200 shrink-0 flex items-center justify-center text-xs">✓</div>
              <div>
                <div className="text-neutral-900 mb-1">Actionable Energy Insights</div>
                <div className="text-xs text-neutral-600">Understand which appliances drive your consumption and when</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 border-l-4 border-neutral-800 pl-4 py-2">
              <div className="w-6 h-6 border border-neutral-700 bg-neutral-200 shrink-0 flex items-center justify-center text-xs">✓</div>
              <div>
                <div className="text-neutral-900 mb-1">Cost & Carbon Reduction</div>
                <div className="text-xs text-neutral-600">Identify waste, optimize schedules, and lower energy bills</div>
              </div>
            </div>
            
            <div className="flex items-start gap-3 border-l-4 border-neutral-800 pl-4 py-2">
              <div className="w-6 h-6 border border-neutral-700 bg-neutral-200 shrink-0 flex items-center justify-center text-xs">✓</div>
              <div>
                <div className="text-neutral-900 mb-1">Model Confidence Metrics</div>
                <div className="text-xs text-neutral-600">Every prediction includes a confidence score—transparency you can trust</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="border-t-2 border-neutral-400 py-16 text-center">
        <div className="text-2xl text-neutral-900 mb-4">Ready to get started?</div>
        <div className="text-sm text-neutral-600 mb-6">Sign up for free and start analyzing your energy data</div>
        <div className="px-8 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm inline-flex items-center gap-2 cursor-pointer hover:bg-neutral-700">
          Create Free Account <ArrowRight className="w-4 h-4" />
        </div>
      </div>
    </PublicLayout>
  );
}
