import { PublicLayout } from '../layouts/PublicLayout';
import { Mail, MessageSquare, FileText } from 'lucide-react';

export function PublicContact() {
  return (
    <PublicLayout title="CONTACT (/contact)">
      <div className="max-w-5xl mx-auto px-8 py-16">
        <div className="text-3xl text-neutral-900 mb-2 text-center">Get in Touch</div>
        <div className="text-sm text-neutral-600 mb-12 text-center">
          Have questions? We're here to help.
        </div>
        
        <div className="grid grid-cols-2 gap-8">
          {/* Left: Contact Form */}
          <div className="border-2 border-neutral-700 bg-white p-6">
            <div className="text-base text-neutral-900 mb-4">Send us a message</div>
            
            <div className="space-y-4">
              <div>
                <div className="text-xs text-neutral-700 mb-1">Name</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[Input field]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Email</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[Input field]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Subject</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[Input field]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Message</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2 h-32">
                  <div className="text-xs text-neutral-400">[Textarea]</div>
                </div>
              </div>
              
              <div className="pt-2">
                <div className="px-6 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm text-center cursor-pointer hover:bg-neutral-700">
                  Send Message
                </div>
              </div>
            </div>
          </div>
          
          {/* Right: Contact Info */}
          <div className="space-y-6">
            {/* Email */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-100 flex items-center justify-center shrink-0">
                  <Mail className="w-6 h-6 text-neutral-700" />
                </div>
                <div>
                  <div className="text-sm text-neutral-900 mb-1">Email Us</div>
                  <div className="text-xs text-neutral-700 mb-2">
                    For general inquiries and support
                  </div>
                  <div className="text-xs text-neutral-900 underline">support@energymonitor.app</div>
                </div>
              </div>
            </div>
            
            {/* Support */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-100 flex items-center justify-center shrink-0">
                  <MessageSquare className="w-6 h-6 text-neutral-700" />
                </div>
                <div>
                  <div className="text-sm text-neutral-900 mb-1">Live Chat</div>
                  <div className="text-xs text-neutral-700 mb-2">
                    Chat with our team (Mon–Fri, 9am–5pm EST)
                  </div>
                  <div className="px-4 py-2 border border-neutral-700 bg-neutral-50 text-xs inline-block cursor-pointer hover:bg-neutral-100">
                    Start Chat
                  </div>
                </div>
              </div>
            </div>
            
            {/* Documentation */}
            <div className="border-2 border-neutral-700 bg-white p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-100 flex items-center justify-center shrink-0">
                  <FileText className="w-6 h-6 text-neutral-700" />
                </div>
                <div>
                  <div className="text-sm text-neutral-900 mb-1">Documentation</div>
                  <div className="text-xs text-neutral-700 mb-2">
                    Browse our comprehensive docs and API reference
                  </div>
                  <div className="text-xs text-neutral-900 underline cursor-pointer">View Docs →</div>
                </div>
              </div>
            </div>
            
            {/* FAQ Link */}
            <div className="border border-neutral-400 bg-neutral-50 p-4">
              <div className="text-sm text-neutral-900 mb-2">Frequently Asked Questions</div>
              <div className="text-xs text-neutral-700 mb-2">
                Find answers to common questions about NILM, pricing, and data requirements.
              </div>
              <div className="text-xs text-neutral-900 underline cursor-pointer">Browse FAQ →</div>
            </div>
          </div>
        </div>
        
        {/* Bottom Notice */}
        <div className="mt-12 border-t-2 border-neutral-400 pt-8 text-center">
          <div className="text-sm text-neutral-700 mb-2">Enterprise Inquiries</div>
          <div className="text-xs text-neutral-600 max-w-2xl mx-auto">
            Need a custom plan, on-premise deployment, or have 100+ buildings? 
            Contact our enterprise team at <span className="underline">enterprise@energymonitor.app</span>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
