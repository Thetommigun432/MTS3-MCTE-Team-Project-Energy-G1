import { PublicLayout } from '../layouts/PublicLayout';

export function PublicAbout() {
  return (
    <PublicLayout title="ABOUT (/about)">
      <div className="max-w-4xl mx-auto px-8 py-16">
        <div className="text-3xl text-neutral-900 mb-6">About Energy Monitor</div>
        
        <div className="space-y-6 text-sm text-neutral-700 leading-relaxed">
          <div className="border-l-4 border-neutral-800 pl-6 py-4 bg-neutral-50">
            <div className="text-base text-neutral-900 mb-2">Our Mission</div>
            <div>
              Energy Monitor uses cutting-edge Non-Intrusive Load Monitoring (NILM) technology to help 
              buildings understand their energy consumption at the appliance level—without installing 
              expensive hardware on every device.
            </div>
          </div>
          
          <div>
            <div className="text-base text-neutral-900 mb-3">What is NILM?</div>
            <div className="mb-3">
              NILM (Non-Intrusive Load Monitoring) is an AI-powered approach that analyzes a building's 
              total electrical consumption to identify individual appliances and estimate their energy usage. 
              Think of it as "energy fingerprinting"—each appliance has a unique electrical signature.
            </div>
            <div className="h-32 border-2 border-neutral-400 bg-neutral-100 flex items-center justify-center text-xs text-neutral-500">
              [Diagram: Total signal → AI model → Disaggregated appliances]
            </div>
          </div>
          
          <div>
            <div className="text-base text-neutral-900 mb-3">How We're Different</div>
            <div className="grid grid-cols-2 gap-4">
              <div className="border border-neutral-400 p-4 bg-white">
                <div className="text-sm text-neutral-900 mb-2">Traditional Approach</div>
                <div className="text-xs text-neutral-600 space-y-1">
                  <div>• Install sensors on every appliance</div>
                  <div>• High upfront cost</div>
                  <div>• Complex installation</div>
                  <div>• Maintenance overhead</div>
                </div>
              </div>
              
              <div className="border-2 border-neutral-800 p-4 bg-neutral-50">
                <div className="text-sm text-neutral-900 mb-2">Energy Monitor (NILM)</div>
                <div className="text-xs text-neutral-700 space-y-1">
                  <div>• One sensor at main meter</div>
                  <div>• Minimal hardware cost</div>
                  <div>• Software-based analysis</div>
                  <div>• Zero maintenance</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <div className="text-base text-neutral-900 mb-3">Our Technology</div>
            <div className="mb-2">
              We leverage machine learning models trained on thousands of appliance signatures to deliver:
            </div>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-2 shrink-0"></div>
                <div><strong>Real-time predictions:</strong> See what's on right now with confidence scores</div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-2 shrink-0"></div>
                <div><strong>Historical analysis:</strong> Understand usage patterns over time</div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-2 shrink-0"></div>
                <div><strong>Transparent confidence:</strong> Every prediction includes a confidence metric</div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-2 shrink-0"></div>
                <div><strong>Scalable platform:</strong> From single buildings to enterprise portfolios</div>
              </div>
            </div>
          </div>
          
          <div className="border-t-2 border-neutral-400 pt-6 mt-8">
            <div className="text-base text-neutral-900 mb-3">Who We Serve</div>
            <div className="grid grid-cols-3 gap-4 text-xs">
              <div className="border border-neutral-400 p-3 text-center">
                <div className="text-sm text-neutral-900 mb-1">Facility Managers</div>
                <div className="text-neutral-600">Optimize building operations</div>
              </div>
              <div className="border border-neutral-400 p-3 text-center">
                <div className="text-sm text-neutral-900 mb-1">Energy Consultants</div>
                <div className="text-neutral-600">Data-driven audits</div>
              </div>
              <div className="border border-neutral-400 p-3 text-center">
                <div className="text-sm text-neutral-900 mb-1">Researchers</div>
                <div className="text-neutral-600">Study consumption patterns</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
