import { PublicLayout } from '../layouts/PublicLayout';
import { Book, Code, Database, Settings } from 'lucide-react';

export function PublicDocs() {
  return (
    <PublicLayout title="DOCS (/docs)">
      <div className="flex h-full">
        {/* Sidebar TOC */}
        <div className="w-64 border-r-2 border-neutral-400 bg-neutral-50 p-6 overflow-y-auto">
          <div className="text-base text-neutral-900 mb-4">Documentation</div>
          
          <div className="space-y-4 text-xs">
            <div>
              <div className="text-neutral-900 mb-2 text-sm">Getting Started</div>
              <div className="space-y-1.5 text-neutral-700">
                <div className="pl-2 hover:underline cursor-pointer">Quick Start</div>
                <div className="pl-2 hover:underline cursor-pointer">Installation</div>
                <div className="pl-2 hover:underline cursor-pointer">Authentication</div>
              </div>
            </div>
            
            <div>
              <div className="text-neutral-900 mb-2 text-sm">API Reference</div>
              <div className="space-y-1.5 text-neutral-700">
                <div className="pl-2 hover:underline cursor-pointer underline">Overview</div>
                <div className="pl-2 hover:underline cursor-pointer">Endpoints</div>
                <div className="pl-2 hover:underline cursor-pointer">Authentication</div>
                <div className="pl-2 hover:underline cursor-pointer">Rate Limits</div>
              </div>
            </div>
            
            <div>
              <div className="text-neutral-900 mb-2 text-sm">Data Format</div>
              <div className="space-y-1.5 text-neutral-700">
                <div className="pl-2 hover:underline cursor-pointer">Time Series Schema</div>
                <div className="pl-2 hover:underline cursor-pointer">Building Metadata</div>
                <div className="pl-2 hover:underline cursor-pointer">Appliance Types</div>
              </div>
            </div>
            
            <div>
              <div className="text-neutral-900 mb-2 text-sm">Model</div>
              <div className="space-y-1.5 text-neutral-700">
                <div className="pl-2 hover:underline cursor-pointer">How NILM Works</div>
                <div className="pl-2 hover:underline cursor-pointer">Confidence Scores</div>
                <div className="pl-2 hover:underline cursor-pointer">Training Data</div>
              </div>
            </div>
            
            <div>
              <div className="text-neutral-900 mb-2 text-sm">Dashboard</div>
              <div className="space-y-1.5 text-neutral-700">
                <div className="pl-2 hover:underline cursor-pointer">Navigation</div>
                <div className="pl-2 hover:underline cursor-pointer">Filters</div>
                <div className="pl-2 hover:underline cursor-pointer">Exporting Data</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-3xl">
            <div className="text-2xl text-neutral-900 mb-2">API Reference</div>
            <div className="text-sm text-neutral-600 mb-8">Access Energy Monitor data programmatically</div>
            
            {/* Quick Links */}
            <div className="grid grid-cols-4 gap-4 mb-8">
              <div className="border-2 border-neutral-700 p-4 bg-white text-center cursor-pointer hover:bg-neutral-50">
                <Book className="w-6 h-6 mx-auto mb-2 text-neutral-700" />
                <div className="text-xs text-neutral-900">Quick Start</div>
              </div>
              <div className="border-2 border-neutral-700 p-4 bg-white text-center cursor-pointer hover:bg-neutral-50">
                <Code className="w-6 h-6 mx-auto mb-2 text-neutral-700" />
                <div className="text-xs text-neutral-900">Code Examples</div>
              </div>
              <div className="border-2 border-neutral-700 p-4 bg-white text-center cursor-pointer hover:bg-neutral-50">
                <Database className="w-6 h-6 mx-auto mb-2 text-neutral-700" />
                <div className="text-xs text-neutral-900">Data Schema</div>
              </div>
              <div className="border-2 border-neutral-700 p-4 bg-white text-center cursor-pointer hover:bg-neutral-50">
                <Settings className="w-6 h-6 mx-auto mb-2 text-neutral-700" />
                <div className="text-xs text-neutral-900">Configuration</div>
              </div>
            </div>
            
            {/* Content Sections */}
            <div className="space-y-8 text-sm text-neutral-700">
              <div>
                <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Authentication</div>
                <div className="mb-3">All API requests require authentication using an API key passed in the header:</div>
                <div className="bg-neutral-900 text-neutral-100 p-4 text-xs font-mono border border-neutral-700">
                  <div>Authorization: Bearer YOUR_API_KEY</div>
                </div>
                <div className="mt-2 text-xs text-neutral-600">
                  Get your API key from Settings → API Keys in the dashboard.
                </div>
              </div>
              
              <div>
                <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Base URL</div>
                <div className="bg-neutral-100 p-3 border border-neutral-400 text-xs font-mono">
                  https://api.energymonitor.app/v1
                </div>
              </div>
              
              <div>
                <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Endpoints</div>
                
                <div className="space-y-4">
                  {/* Endpoint 1 */}
                  <div className="border border-neutral-400 p-4 bg-white">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="px-2 py-1 bg-neutral-800 text-white text-xs">GET</div>
                      <div className="text-xs font-mono text-neutral-900">/buildings</div>
                    </div>
                    <div className="text-xs text-neutral-700 mb-2">List all buildings in your organization</div>
                    <div className="bg-neutral-900 text-neutral-100 p-3 text-xs font-mono">
                      <div>curl -H "Authorization: Bearer TOKEN" \</div>
                      <div className="pl-4">https://api.energymonitor.app/v1/buildings</div>
                    </div>
                  </div>
                  
                  {/* Endpoint 2 */}
                  <div className="border border-neutral-400 p-4 bg-white">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="px-2 py-1 bg-neutral-800 text-white text-xs">GET</div>
                      <div className="text-xs font-mono text-neutral-900">/predictions</div>
                    </div>
                    <div className="text-xs text-neutral-700 mb-2">Get appliance predictions for a building and date range</div>
                    <div className="mb-2 text-xs">
                      <strong>Query parameters:</strong>
                      <div className="pl-4 text-neutral-600 mt-1 space-y-0.5">
                        <div>• building_id (required)</div>
                        <div>• start_time (ISO 8601)</div>
                        <div>• end_time (ISO 8601)</div>
                      </div>
                    </div>
                    <div className="bg-neutral-900 text-neutral-100 p-3 text-xs font-mono">
                      <div>curl -H "Authorization: Bearer TOKEN" \</div>
                      <div className="pl-4">"https://api.energymonitor.app/v1/predictions</div>
                      <div className="pl-4">?building_id=bldg_123&start_time=2026-01-01T00:00:00Z"</div>
                    </div>
                  </div>
                  
                  {/* Endpoint 3 */}
                  <div className="border border-neutral-400 p-4 bg-white">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="px-2 py-1 bg-neutral-800 text-white text-xs">POST</div>
                      <div className="text-xs font-mono text-neutral-900">/data/upload</div>
                    </div>
                    <div className="text-xs text-neutral-700 mb-2">Upload time-series consumption data (CSV format)</div>
                    <div className="bg-neutral-900 text-neutral-100 p-3 text-xs font-mono">
                      <div>curl -X POST -H "Authorization: Bearer TOKEN" \</div>
                      <div className="pl-4">-F "file=@consumption.csv" \</div>
                      <div className="pl-4">https://api.energymonitor.app/v1/data/upload</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="text-base text-neutral-900 mb-3 pb-2 border-b border-neutral-400">Rate Limits</div>
                <div className="border border-neutral-400 p-4 bg-neutral-50">
                  <div className="text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-neutral-700">Free tier:</span>
                      <span className="text-neutral-900">100 requests/hour</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-700">Pro tier:</span>
                      <span className="text-neutral-900">1,000 requests/hour</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-700">Enterprise:</span>
                      <span className="text-neutral-900">Custom limits</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
