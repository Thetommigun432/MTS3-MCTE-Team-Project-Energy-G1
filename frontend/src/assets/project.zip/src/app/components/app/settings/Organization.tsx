import { AppShell } from '../../layouts/AppShell';

export function AppSettingsOrg() {
  return (
    <AppShell title="SETTINGS — ORGANIZATION (/app/settings/org)" activeNav="settings">
      <div className="p-6 space-y-6">
        
        {/* Settings Nav */}
        <div className="flex gap-6 text-sm border-b-2 border-neutral-400 pb-4">
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Profile</div>
          <div className="pb-2 border-b-2 border-neutral-900 text-neutral-900 cursor-pointer">Organization</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Users</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">API Keys</div>
        </div>
        
        {/* Organization Settings */}
        <div className="max-w-2xl space-y-6">
          
          {/* Organization Info */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Organization Information</div>
            
            <div className="space-y-4">
              <div>
                <div className="text-xs text-neutral-700 mb-1">Organization Name</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs">Acme Corporation</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Organization ID</div>
                <div className="border-2 border-neutral-600 bg-neutral-100 px-3 py-2">
                  <div className="text-xs text-neutral-600 font-mono">org_abc123xyz</div>
                </div>
                <div className="text-xs text-neutral-500 mt-1">Used for API authentication</div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Industry</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs">Commercial Real Estate</div>
                </div>
              </div>
              
              <div className="pt-2">
                <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700 inline-block">
                  Save Changes
                </div>
              </div>
            </div>
          </div>
          
          {/* Plan & Billing */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Plan & Billing</div>
            
            <div className="space-y-4">
              <div className="border border-neutral-400 bg-neutral-50 p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm text-neutral-900">Professional Plan</div>
                    <div className="text-xs text-neutral-600 mt-1">Up to 10 buildings, API access, priority support</div>
                  </div>
                  <div className="text-xl text-neutral-900">$99<span className="text-sm text-neutral-600">/mo</span></div>
                </div>
                
                <div className="flex gap-3">
                  <div className="px-4 py-2 border border-neutral-700 bg-white text-sm cursor-pointer hover:bg-neutral-50">
                    Change Plan
                  </div>
                  <div className="px-4 py-2 border border-neutral-500 bg-neutral-100 text-sm cursor-pointer hover:bg-neutral-200">
                    View Invoice History
                  </div>
                </div>
              </div>
              
              <div className="text-xs text-neutral-700 space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Current billing period:</span>
                  <span>Jan 1 - Jan 31, 2026</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Buildings used:</span>
                  <span>3 / 10</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Next billing date:</span>
                  <span>Feb 1, 2026</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Usage Stats */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Usage Statistics (Current Month)</div>
            
            <div className="space-y-3 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-neutral-700">API Calls</span>
                <div className="flex items-center gap-3">
                  <div className="w-48 h-4 border border-neutral-400 bg-neutral-100">
                    <div className="h-full bg-neutral-800" style={{ width: '45%' }}></div>
                  </div>
                  <span className="text-neutral-900 w-20 text-right">4,500 / 10,000</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-neutral-700">Data Storage</span>
                <div className="flex items-center gap-3">
                  <div className="w-48 h-4 border border-neutral-400 bg-neutral-100">
                    <div className="h-full bg-neutral-800" style={{ width: '22%' }}></div>
                  </div>
                  <span className="text-neutral-900 w-20 text-right">2.2 GB / 10 GB</span>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-neutral-700">Model Runs</span>
                <div className="flex items-center gap-3">
                  <div className="w-48 h-4 border border-neutral-400 bg-neutral-100">
                    <div className="h-full bg-neutral-800" style={{ width: '8%' }}></div>
                  </div>
                  <span className="text-neutral-900 w-20 text-right">8 / 100</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
