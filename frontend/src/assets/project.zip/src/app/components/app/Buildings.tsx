import { AppShell } from '../layouts/AppShell';
import { Plus, Eye, Edit, Trash2 } from 'lucide-react';

export function AppBuildings() {
  return (
    <AppShell title="BUILDINGS (/app/buildings)" activeNav="buildings">
      <div className="p-6 space-y-6">
        
        {/* Page Header */}
        <div className="flex items-center justify-between border-b-2 border-neutral-400 pb-4">
          <div>
            <div className="text-xl text-neutral-900 mb-1">Buildings</div>
            <div className="text-xs text-neutral-600">Manage buildings in your organization</div>
          </div>
          <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700 flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Building
          </div>
        </div>
        
        {/* Buildings Table */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">All Buildings</div>
            <div className="text-xs text-neutral-500">3 buildings</div>
          </div>
          
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-400 bg-neutral-100">
                <th className="text-left px-4 py-2 text-neutral-700">Building Name</th>
                <th className="text-left px-4 py-2 text-neutral-700">Building ID</th>
                <th className="text-left px-4 py-2 text-neutral-700">Location</th>
                <th className="text-left px-4 py-2 text-neutral-700">Last Data</th>
                <th className="text-left px-4 py-2 text-neutral-700">Status</th>
                <th className="text-left px-4 py-2 text-neutral-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="text-neutral-900">Building A</div>
                  <div className="text-neutral-600 mt-0.5">Main Office</div>
                </td>
                <td className="px-4 py-3 font-mono">bldg_001</td>
                <td className="px-4 py-3">New York, NY</td>
                <td className="px-4 py-3">Jan 7, 14:23</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
              
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="text-neutral-900">Building B</div>
                  <div className="text-neutral-600 mt-0.5">Warehouse</div>
                </td>
                <td className="px-4 py-3 font-mono">bldg_002</td>
                <td className="px-4 py-3">Newark, NJ</td>
                <td className="px-4 py-3">Jan 7, 14:15</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
              
              <tr className="hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="text-neutral-900">Building C</div>
                  <div className="text-neutral-600 mt-0.5">Retail Store</div>
                </td>
                <td className="px-4 py-3 font-mono">bldg_003</td>
                <td className="px-4 py-3">Boston, MA</td>
                <td className="px-4 py-3">Jan 5, 08:12</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 border border-neutral-600 bg-neutral-200">Inactive</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        {/* Add Building Modal (wireframe) */}
        <div className="border-2 border-neutral-700 bg-white p-6">
          <div className="text-sm text-neutral-900 mb-4">Add Building Modal (wireframe)</div>
          <div className="space-y-4 max-w-md">
            <div>
              <div className="text-xs text-neutral-700 mb-1">Building Name</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                <div className="text-xs text-neutral-400">[Building name]</div>
              </div>
            </div>
            
            <div>
              <div className="text-xs text-neutral-700 mb-1">Building ID</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                <div className="text-xs text-neutral-400">[bldg_XXX]</div>
              </div>
            </div>
            
            <div>
              <div className="text-xs text-neutral-700 mb-1">Location</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                <div className="text-xs text-neutral-400">[City, State]</div>
              </div>
            </div>
            
            <div className="flex gap-3 pt-2">
              <div className="px-5 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer">
                Create Building
              </div>
              <div className="px-5 py-2 border border-neutral-500 bg-white text-sm cursor-pointer">
                Cancel
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
