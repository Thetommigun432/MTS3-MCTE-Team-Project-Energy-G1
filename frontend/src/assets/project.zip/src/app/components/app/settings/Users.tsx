import { AppShell } from '../../layouts/AppShell';
import { UserPlus, Mail, Edit, Trash2, ChevronDown } from 'lucide-react';

export function AppSettingsUsers() {
  return (
    <AppShell title="SETTINGS — USERS (/app/settings/users)" activeNav="settings">
      <div className="p-6 space-y-6">
        
        {/* Settings Nav */}
        <div className="flex gap-6 text-sm border-b-2 border-neutral-400 pb-4">
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Profile</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Organization</div>
          <div className="pb-2 border-b-2 border-neutral-900 text-neutral-900 cursor-pointer">Users</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">API Keys</div>
        </div>
        
        {/* Invite User Section */}
        <div className="border-2 border-neutral-700 bg-white p-5">
          <div className="text-sm text-neutral-900 mb-4 flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            <span>Invite New User</span>
          </div>
          
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <div className="text-xs text-neutral-700 mb-1">Email Address</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex items-center gap-2">
                <Mail className="w-4 h-4 text-neutral-500" />
                <div className="text-xs text-neutral-400 flex-1">[user@example.com]</div>
              </div>
            </div>
            
            <div className="w-48">
              <div className="text-xs text-neutral-700 mb-1">Role</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex items-center justify-between">
                <span className="text-xs">Member</span>
                <ChevronDown className="w-3 h-3" />
              </div>
            </div>
            
            <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700">
              Send Invite
            </div>
          </div>
          
          <div className="mt-3 text-xs text-neutral-600">
            The user will receive an email invitation to join your organization.
          </div>
        </div>
        
        {/* Role Descriptions */}
        <div className="border border-neutral-400 bg-neutral-50 p-4">
          <div className="text-xs text-neutral-900 mb-2">Role Permissions:</div>
          <div className="space-y-1 text-xs text-neutral-700">
            <div><strong>Admin:</strong> Full access, manage users, billing, and settings</div>
            <div><strong>Member:</strong> View and edit dashboards, manage buildings, export data</div>
            <div><strong>Viewer:</strong> View-only access to dashboards and reports</div>
          </div>
        </div>
        
        {/* Users Table */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">Team Members</div>
            <div className="text-xs text-neutral-500">4 active users</div>
          </div>
          
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-400 bg-neutral-100">
                <th className="text-left px-4 py-2 text-neutral-700">Name</th>
                <th className="text-left px-4 py-2 text-neutral-700">Email</th>
                <th className="text-left px-4 py-2 text-neutral-700">Role</th>
                <th className="text-left px-4 py-2 text-neutral-700">Status</th>
                <th className="text-left px-4 py-2 text-neutral-700">Last Active</th>
                <th className="text-left px-4 py-2 text-neutral-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 border border-neutral-600 bg-neutral-300 rounded-full"></div>
                    <span>John Doe</span>
                  </div>
                </td>
                <td className="px-4 py-3">john.doe@example.com</td>
                <td className="px-4 py-3">
                  <div className="border-2 border-neutral-600 bg-white px-2 py-1 inline-flex items-center gap-1">
                    <span>Admin</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
                <td className="px-4 py-3">2 minutes ago</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-400 cursor-not-allowed" />
                  </div>
                </td>
              </tr>
              
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 border border-neutral-600 bg-neutral-300 rounded-full"></div>
                    <span>Jane Smith</span>
                  </div>
                </td>
                <td className="px-4 py-3">jane.smith@example.com</td>
                <td className="px-4 py-3">
                  <div className="border-2 border-neutral-600 bg-white px-2 py-1 inline-flex items-center gap-1">
                    <span>Member</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
                <td className="px-4 py-3">1 hour ago</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
              
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 border border-neutral-600 bg-neutral-300 rounded-full"></div>
                    <span>Bob Wilson</span>
                  </div>
                </td>
                <td className="px-4 py-3">bob.wilson@example.com</td>
                <td className="px-4 py-3">
                  <div className="border-2 border-neutral-600 bg-white px-2 py-1 inline-flex items-center gap-1">
                    <span>Viewer</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
                <td className="px-4 py-3">Yesterday</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Edit className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
              
              <tr className="hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 border border-neutral-600 bg-neutral-300 rounded-full"></div>
                    <span>Alice Johnson</span>
                  </div>
                </td>
                <td className="px-4 py-3">alice.johnson@example.com</td>
                <td className="px-4 py-3">
                  <div className="border-2 border-neutral-600 bg-white px-2 py-1 inline-flex items-center gap-1">
                    <span>Member</span>
                    <ChevronDown className="w-3 h-3" />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 border border-neutral-600 bg-yellow-100">Pending</span>
                </td>
                <td className="px-4 py-3 text-neutral-500">Invited 2 days ago</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" title="Resend invite" />
                    <Trash2 className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
