import { AppShell } from '../../layouts/AppShell';

export function AppSettingsProfile() {
  return (
    <AppShell title="SETTINGS — PROFILE (/app/settings/profile)" activeNav="settings">
      <div className="p-6 space-y-6">
        
        {/* Settings Nav */}
        <div className="flex gap-6 text-sm border-b-2 border-neutral-400 pb-4">
          <div className="pb-2 border-b-2 border-neutral-900 text-neutral-900 cursor-pointer">Profile</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Organization</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">Users</div>
          <div className="pb-2 text-neutral-600 cursor-pointer hover:text-neutral-900">API Keys</div>
        </div>
        
        {/* Profile Settings */}
        <div className="max-w-2xl space-y-6">
          
          {/* Basic Info */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Basic Information</div>
            
            <div className="space-y-4">
              <div>
                <div className="text-xs text-neutral-700 mb-1">Full Name</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs">John Doe</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Email</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs">john.doe@example.com</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Role</div>
                <div className="border-2 border-neutral-600 bg-neutral-100 px-3 py-2">
                  <div className="text-xs text-neutral-600">Admin (cannot be changed)</div>
                </div>
              </div>
              
              <div className="pt-2">
                <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700 inline-block">
                  Save Changes
                </div>
              </div>
            </div>
          </div>
          
          {/* Change Password */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Change Password</div>
            
            <div className="space-y-4">
              <div>
                <div className="text-xs text-neutral-700 mb-1">Current Password</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[••••••••]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">New Password</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[••••••••]</div>
                </div>
              </div>
              
              <div>
                <div className="text-xs text-neutral-700 mb-1">Confirm New Password</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                  <div className="text-xs text-neutral-400">[••••••••]</div>
                </div>
              </div>
              
              <div className="pt-2">
                <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700 inline-block">
                  Update Password
                </div>
              </div>
            </div>
          </div>
          
          {/* Notifications */}
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Notification Preferences</div>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-neutral-900">Email notifications</div>
                  <div className="text-xs text-neutral-600 mt-0.5">Receive email alerts for system events</div>
                </div>
                <div className="w-12 h-6 border-2 border-neutral-700 bg-neutral-800 rounded-full relative">
                  <div className="w-4 h-4 bg-white rounded-full absolute right-1 top-0.5"></div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-neutral-900">Data alerts</div>
                  <div className="text-xs text-neutral-600 mt-0.5">Alert when data gaps detected</div>
                </div>
                <div className="w-12 h-6 border-2 border-neutral-700 bg-neutral-800 rounded-full relative">
                  <div className="w-4 h-4 bg-white rounded-full absolute right-1 top-0.5"></div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-neutral-900">Weekly reports</div>
                  <div className="text-xs text-neutral-600 mt-0.5">Receive weekly summary emails</div>
                </div>
                <div className="w-12 h-6 border-2 border-neutral-700 bg-neutral-200 rounded-full relative">
                  <div className="w-4 h-4 bg-white rounded-full absolute left-1 top-0.5"></div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Danger Zone */}
          <div className="border-2 border-red-400 bg-red-50 p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-red-300">Danger Zone</div>
            
            <div className="space-y-3 text-xs">
              <div>
                <div className="text-neutral-900 mb-1">Delete Account</div>
                <div className="text-neutral-600 mb-2">
                  Once you delete your account, there is no going back. Please be certain.
                </div>
                <div className="px-4 py-2 border-2 border-red-600 bg-white text-red-800 inline-block cursor-pointer hover:bg-red-50">
                  Delete Account
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
