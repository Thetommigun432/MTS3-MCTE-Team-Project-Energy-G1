import { AppShell } from '../layouts/AppShell';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChevronLeft } from 'lucide-react';

const applianceData = [
  { time: '00:00', kW: 0.5 }, { time: '03:00', kW: 0.5 }, { time: '06:00', kW: 0.5 },
  { time: '09:00', kW: 0.5 }, { time: '12:00', kW: 0.5 }, { time: '15:00', kW: 0.5 },
  { time: '18:00', kW: 0.5 }, { time: '21:00', kW: 0.5 },
];

export function AppApplianceDetails() {
  return (
    <AppShell title="APPLIANCE DETAILS (/app/appliances/:name)" activeNav="appliances">
      <div className="p-6 space-y-6">
        
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-700 cursor-pointer hover:underline">
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </div>
        
        {/* Page Header */}
        <div className="border-b-2 border-neutral-400 pb-4">
          <div className="text-xl text-neutral-900 mb-1">Refrigerator</div>
          <div className="text-xs text-neutral-600">Appliance details and consumption analysis</div>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Current Status</div>
            <div className="text-2xl text-neutral-900">ON</div>
            <div className="text-xs text-neutral-500 mt-1">78% confidence</div>
          </div>
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Current Draw</div>
            <div className="text-2xl text-neutral-900">0.5 kW</div>
            <div className="text-xs text-neutral-500 mt-1">Estimated</div>
          </div>
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Total Energy (7d)</div>
            <div className="text-2xl text-neutral-900">84 kWh</div>
            <div className="text-xs text-neutral-500 mt-1">Jan 1-7</div>
          </div>
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Avg Runtime</div>
            <div className="text-2xl text-neutral-900">24 hrs</div>
            <div className="text-xs text-neutral-500 mt-1">Always on</div>
          </div>
        </div>
        
        {/* Consumption Chart */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">Estimated Power Consumption (kW)</div>
            <div className="text-xs text-neutral-500">Refrigerator | 15-minute resolution | Jan 1–7</div>
          </div>
          <div className="p-4">
            <div className="h-64 bg-neutral-50 border border-neutral-400">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={applianceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#a3a3a3" />
                  <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#525252' }} />
                  <YAxis tick={{ fontSize: 10, fill: '#525252' }} label={{ value: 'kW', angle: -90, position: 'insideLeft', fontSize: 10 }} />
                  <Tooltip contentStyle={{ fontSize: 10, backgroundColor: '#f5f5f5' }} />
                  <Line type="monotone" dataKey="kW" stroke="#404040" strokeWidth={2} dot={{ fill: '#404040', r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        
        {/* ON/OFF Timeline */}
        <div className="border-2 border-neutral-700 bg-white p-4">
          <div className="text-sm text-neutral-900 mb-3">ON/OFF Timeline</div>
          <div className="bg-neutral-50 border border-neutral-400 p-4">
            {['Jan 1', 'Jan 2', 'Jan 3', 'Jan 4', 'Jan 5', 'Jan 6', 'Jan 7'].map(day => (
              <div key={day} className="flex items-center gap-3 mb-2">
                <div className="w-16 text-xs text-neutral-600">{day}</div>
                <div className="flex-1 h-8 bg-neutral-800 border border-neutral-900"></div>
              </div>
            ))}
            <div className="flex gap-4 mt-4 text-xs text-neutral-700">
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-neutral-800 border border-neutral-900"></div>
                <span>ON</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 border border-neutral-600 bg-neutral-200"></div>
                <span>OFF</span>
              </div>
            </div>
          </div>
          <div className="text-xs text-neutral-500 mt-2">Refrigerator typically runs continuously</div>
        </div>
        
        {/* Usage Periods Table */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">Top Usage Periods</div>
            <div className="text-xs text-neutral-500">Highest estimated energy consumption intervals</div>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-400 bg-neutral-100">
                <th className="text-left px-4 py-2 text-neutral-700">Date / Time</th>
                <th className="text-left px-4 py-2 text-neutral-700">Duration</th>
                <th className="text-left px-4 py-2 text-neutral-700">Estimated kWh</th>
                <th className="text-left px-4 py-2 text-neutral-700">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {[7, 6, 5, 4, 3].map(day => (
                <tr key={day} className="border-b border-neutral-300">
                  <td className="px-4 py-2.5">Jan {day}, 00:00 – 23:45</td>
                  <td className="px-4 py-2.5">24 hours</td>
                  <td className="px-4 py-2.5">12.0</td>
                  <td className="px-4 py-2.5">78%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
