import { AppShell } from '../layouts/AppShell';
import { Play, AlertTriangle, CheckCircle } from 'lucide-react';

export function AppModel() {
  return (
    <AppShell title="MODEL (/app/model)" activeNav="model">
      <div className="p-6 space-y-6">
        
        {/* Page Header */}
        <div className="border-b-2 border-neutral-400 pb-4">
          <div className="text-xl text-neutral-900 mb-1">AI Model Status</div>
          <div className="text-xs text-neutral-600">NILM model training and performance metrics</div>
        </div>
        
        {/* Model Status Cards */}
        <div className="grid grid-cols-3 gap-4">
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Current Version</div>
            <div className="text-2xl text-neutral-900">v2.1</div>
            <div className="text-xs text-neutral-500 mt-1">Last trained Dec 15</div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Training Status</div>
            <div className="text-2xl text-neutral-900">Complete</div>
            <div className="text-xs text-neutral-500 mt-1 flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
              Ready for predictions
            </div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Overall Accuracy</div>
            <div className="text-2xl text-neutral-900">87%</div>
            <div className="text-xs text-neutral-500 mt-1">Avg confidence score</div>
          </div>
        </div>
        
        {/* Training Section */}
        <div className="border-2 border-neutral-700 bg-white p-5">
          <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Training Controls</div>
          
          <div className="bg-yellow-50 border border-yellow-400 p-3 mb-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-800 shrink-0" />
            <div className="text-xs text-yellow-900">
              <strong>Note:</strong> Model retraining requires admin permissions and sufficient training data (minimum 30 days).
              Training can take 2-4 hours depending on dataset size.
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <div className="text-xs text-neutral-700 mb-2">Training Data Range</div>
              <div className="flex gap-3 items-center">
                <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex-1">
                  <div className="text-xs text-neutral-400">[Start date]</div>
                </div>
                <div className="text-xs text-neutral-600">to</div>
                <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex-1">
                  <div className="text-xs text-neutral-400">[End date]</div>
                </div>
              </div>
            </div>
            
            <div>
              <div className="text-xs text-neutral-700 mb-2">Buildings to Include</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2">
                <div className="text-xs text-neutral-400">[Select buildings...]</div>
              </div>
            </div>
            
            <div className="pt-2">
              <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-300 text-neutral-600 text-sm inline-flex items-center gap-2 cursor-not-allowed">
                <Play className="w-4 h-4" />
                Retrain Model (Disabled)
              </div>
              <div className="text-xs text-neutral-500 mt-2">
                Contact your administrator to enable model retraining
              </div>
            </div>
          </div>
        </div>
        
        {/* Performance Metrics */}
        <div className="border-2 border-neutral-700 bg-white p-5">
          <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Model Performance Metrics</div>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="border border-neutral-400 p-3 bg-neutral-50">
                <div className="text-neutral-600 mb-1">Mean Absolute Error (MAE)</div>
                <div className="text-lg text-neutral-900">0.12 kW</div>
              </div>
              
              <div className="border border-neutral-400 p-3 bg-neutral-50">
                <div className="text-neutral-600 mb-1">Mean Squared Error (MSE)</div>
                <div className="text-lg text-neutral-900">0.03 kW²</div>
              </div>
              
              <div className="border border-neutral-400 p-3 bg-neutral-50">
                <div className="text-neutral-600 mb-1">F1 Score (ON/OFF detection)</div>
                <div className="text-lg text-neutral-900">0.89</div>
              </div>
              
              <div className="border border-neutral-400 p-3 bg-neutral-50">
                <div className="text-neutral-600 mb-1">Training Samples</div>
                <div className="text-lg text-neutral-900">45,280</div>
              </div>
            </div>
            
            <div className="border border-neutral-400 p-4 bg-white">
              <div className="text-xs text-neutral-900 mb-3">Per-Appliance Accuracy</div>
              <div className="space-y-2">
                {[
                  { name: 'HVAC', acc: 92 },
                  { name: 'Dishwasher', acc: 88 },
                  { name: 'Lighting', acc: 85 },
                  { name: 'Refrigerator', acc: 78 },
                  { name: 'Water Heater', acc: 81 },
                ].map(item => (
                  <div key={item.name} className="flex items-center gap-3">
                    <div className="w-24 text-xs text-neutral-700">{item.name}</div>
                    <div className="flex-1 h-5 border border-neutral-400 bg-neutral-100">
                      <div 
                        className="h-full bg-neutral-800"
                        style={{ width: `${item.acc}%` }}
                      ></div>
                    </div>
                    <div className="w-12 text-xs text-neutral-900 text-right">{item.acc}%</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Training History */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">Training History</div>
            <div className="text-xs text-neutral-500">Recent model training sessions</div>
          </div>
          
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-400 bg-neutral-100">
                <th className="text-left px-4 py-2 text-neutral-700">Version</th>
                <th className="text-left px-4 py-2 text-neutral-700">Trained Date</th>
                <th className="text-left px-4 py-2 text-neutral-700">Data Range</th>
                <th className="text-left px-4 py-2 text-neutral-700">Accuracy</th>
                <th className="text-left px-4 py-2 text-neutral-700">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-neutral-300">
                <td className="px-4 py-2.5">v2.1</td>
                <td className="px-4 py-2.5">Dec 15, 2025</td>
                <td className="px-4 py-2.5">Nov 1 - Dec 14</td>
                <td className="px-4 py-2.5">87%</td>
                <td className="px-4 py-2.5">
                  <span className="px-2 py-0.5 bg-neutral-800 text-white">Active</span>
                </td>
              </tr>
              <tr className="border-b border-neutral-300">
                <td className="px-4 py-2.5">v2.0</td>
                <td className="px-4 py-2.5">Nov 1, 2025</td>
                <td className="px-4 py-2.5">Oct 1 - Oct 31</td>
                <td className="px-4 py-2.5">84%</td>
                <td className="px-4 py-2.5">
                  <span className="px-2 py-0.5 border border-neutral-600 bg-neutral-200">Archived</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
