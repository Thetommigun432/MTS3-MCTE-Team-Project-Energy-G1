import { AppShell } from '../layouts/AppShell';
import { ChevronLeft, ExternalLink } from 'lucide-react';

export function AppBuildingDetail() {
  return (
    <AppShell title="BUILDING DETAIL (/app/buildings/:id)" activeNav="buildings">
      <div className="p-6 space-y-6">
        
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-700 cursor-pointer hover:underline">
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Buildings</span>
        </div>
        
        {/* Page Header */}
        <div className="border-b-2 border-neutral-400 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xl text-neutral-900 mb-1">Building A — Main Office</div>
              <div className="text-xs text-neutral-600">Building ID: bldg_001 | New York, NY</div>
            </div>
            <div className="flex gap-2">
              <div className="px-4 py-2 border border-neutral-500 bg-white text-sm cursor-pointer hover:bg-neutral-50">
                Edit Building
              </div>
              <div className="px-4 py-2 border-2 border-neutral-900 bg-white text-sm cursor-pointer hover:bg-neutral-50 flex items-center gap-2">
                View Dashboard <ExternalLink className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Status</div>
            <div className="text-2xl text-neutral-900">Active</div>
            <div className="text-xs text-neutral-500 mt-1">Receiving data</div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Last Data Point</div>
            <div className="text-2xl text-neutral-900">2 min</div>
            <div className="text-xs text-neutral-500 mt-1">Jan 7, 14:23</div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Data Points (7d)</div>
            <div className="text-2xl text-neutral-900">672</div>
            <div className="text-xs text-neutral-500 mt-1">15-min intervals</div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-4">
            <div className="text-xs text-neutral-600 mb-2">Identified Appliances</div>
            <div className="text-2xl text-neutral-900">6</div>
            <div className="text-xs text-neutral-500 mt-1">By AI model</div>
          </div>
        </div>
        
        {/* Building Info */}
        <div className="grid grid-cols-2 gap-6">
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Building Information</div>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-600">Building Name:</span>
                <span className="text-neutral-900">Building A — Main Office</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Building ID:</span>
                <span className="text-neutral-900 font-mono">bldg_001</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Location:</span>
                <span className="text-neutral-900">New York, NY</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Square Footage:</span>
                <span className="text-neutral-900">12,500 sq ft</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Building Type:</span>
                <span className="text-neutral-900">Commercial Office</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Year Built:</span>
                <span className="text-neutral-900">2015</span>
              </div>
            </div>
          </div>
          
          <div className="border-2 border-neutral-700 bg-white p-5">
            <div className="text-sm text-neutral-900 mb-4 pb-2 border-b border-neutral-400">Data Connection</div>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-600">Connection Type:</span>
                <span className="text-neutral-900">API</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Data Source:</span>
                <span className="text-neutral-900">Smart Meter XYZ-100</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Sampling Rate:</span>
                <span className="text-neutral-900">15 minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Data Format:</span>
                <span className="text-neutral-900">kW (power)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">First Data Point:</span>
                <span className="text-neutral-900">Dec 1, 2025</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Last Synced:</span>
                <span className="text-neutral-900">2 minutes ago</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Data Coverage */}
        <div className="border-2 border-neutral-700 bg-white p-5">
          <div className="text-sm text-neutral-900 mb-4">Data Coverage (Last 30 Days)</div>
          <div className="bg-neutral-50 border border-neutral-400 p-4">
            <div className="text-xs text-neutral-600 mb-3">Calendar heatmap showing data availability</div>
            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: 30 }).map((_, i) => (
                <div 
                  key={i} 
                  className={`h-8 border ${i < 28 ? 'bg-neutral-800 border-neutral-900' : 'bg-neutral-300 border-neutral-500'} flex items-center justify-center text-xs text-white`}
                >
                  {i + 1}
                </div>
              ))}
            </div>
            <div className="flex gap-4 mt-4 text-xs text-neutral-700">
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-neutral-800 border border-neutral-900"></div>
                <span>Complete data</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 border border-neutral-500 bg-neutral-300"></div>
                <span>No data / gaps</span>
              </div>
            </div>
          </div>
          <div className="text-xs text-neutral-500 mt-2">93% data coverage (28/30 days)</div>
        </div>
        
        {/* Action Links */}
        <div className="flex gap-4">
          <div className="px-5 py-2.5 border-2 border-neutral-900 bg-white text-sm cursor-pointer hover:bg-neutral-50">
            View Dashboard (Filtered) →
          </div>
          <div className="px-5 py-2.5 border border-neutral-500 bg-neutral-100 text-sm cursor-pointer hover:bg-neutral-200">
            Export Building Data
          </div>
        </div>
      </div>
    </AppShell>
  );
}
