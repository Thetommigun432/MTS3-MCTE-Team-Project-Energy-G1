import { AppShell } from '../layouts/AppShell';
import { Download, FileText, ChevronDown } from 'lucide-react';

export function AppReports() {
  return (
    <AppShell title="REPORTS (/app/reports)" activeNav="reports">
      <div className="p-6 space-y-6">
        
        {/* Page Header */}
        <div className="border-b-2 border-neutral-400 pb-4">
          <div className="text-xl text-neutral-900 mb-1">Reports & Export</div>
          <div className="text-xs text-neutral-600">Generate and download consumption reports</div>
        </div>
        
        {/* Generate Report Section */}
        <div className="border-2 border-neutral-700 bg-white p-5">
          <div className="text-sm text-neutral-900 mb-4">Generate New Report</div>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <div className="text-xs text-neutral-700 mb-1">Building</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex items-center justify-between">
                <span className="text-xs">Building A</span>
                <ChevronDown className="w-3 h-3" />
              </div>
            </div>
            
            <div>
              <div className="text-xs text-neutral-700 mb-1">Date Range</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex items-center justify-between">
                <span className="text-xs">Last 7 days</span>
                <ChevronDown className="w-3 h-3" />
              </div>
            </div>
            
            <div>
              <div className="text-xs text-neutral-700 mb-1">Appliances</div>
              <div className="border-2 border-neutral-600 bg-white px-3 py-2 flex items-center justify-between">
                <span className="text-xs">All appliances</span>
                <ChevronDown className="w-3 h-3" />
              </div>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="text-xs text-neutral-700 mb-2">Export Format</div>
            <div className="flex gap-3">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-neutral-800"></div>
                <span className="text-xs">CSV</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-white"></div>
                <span className="text-xs">PDF</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-neutral-700 bg-white"></div>
                <span className="text-xs">JSON</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3">
            <div className="px-5 py-2.5 border-2 border-neutral-900 bg-neutral-800 text-white text-sm cursor-pointer hover:bg-neutral-700">
              Generate Report
            </div>
            <div className="px-5 py-2.5 border border-neutral-500 bg-neutral-100 text-sm cursor-pointer hover:bg-neutral-200">
              Schedule Report
            </div>
          </div>
        </div>
        
        {/* Generated Reports Table */}
        <div className="border-2 border-neutral-700 bg-white">
          <div className="px-4 py-3 border-b border-neutral-400 bg-neutral-50">
            <div className="text-sm text-neutral-900">Recent Reports</div>
            <div className="text-xs text-neutral-500">Generated reports (last 30 days)</div>
          </div>
          
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-neutral-400 bg-neutral-100">
                <th className="text-left px-4 py-2 text-neutral-700">Report Name</th>
                <th className="text-left px-4 py-2 text-neutral-700">Building</th>
                <th className="text-left px-4 py-2 text-neutral-700">Date Range</th>
                <th className="text-left px-4 py-2 text-neutral-700">Format</th>
                <th className="text-left px-4 py-2 text-neutral-700">Generated</th>
                <th className="text-left px-4 py-2 text-neutral-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-2.5 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-neutral-600" />
                  <span>Weekly Consumption Report</span>
                </td>
                <td className="px-4 py-2.5">Building A</td>
                <td className="px-4 py-2.5">Jan 1-7, 2026</td>
                <td className="px-4 py-2.5">CSV</td>
                <td className="px-4 py-2.5">Jan 7, 14:00</td>
                <td className="px-4 py-2.5">
                  <Download className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                </td>
              </tr>
              
              <tr className="border-b border-neutral-300 hover:bg-neutral-50">
                <td className="px-4 py-2.5 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-neutral-600" />
                  <span>Appliance Breakdown</span>
                </td>
                <td className="px-4 py-2.5">Building A</td>
                <td className="px-4 py-2.5">Dec 25-31, 2025</td>
                <td className="px-4 py-2.5">PDF</td>
                <td className="px-4 py-2.5">Jan 1, 09:15</td>
                <td className="px-4 py-2.5">
                  <Download className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                </td>
              </tr>
              
              <tr className="hover:bg-neutral-50">
                <td className="px-4 py-2.5 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-neutral-600" />
                  <span>Monthly Energy Summary</span>
                </td>
                <td className="px-4 py-2.5">All Buildings</td>
                <td className="px-4 py-2.5">Dec 1-31, 2025</td>
                <td className="px-4 py-2.5">CSV</td>
                <td className="px-4 py-2.5">Dec 31, 23:00</td>
                <td className="px-4 py-2.5">
                  <Download className="w-4 h-4 text-neutral-600 cursor-pointer hover:text-neutral-900" />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
