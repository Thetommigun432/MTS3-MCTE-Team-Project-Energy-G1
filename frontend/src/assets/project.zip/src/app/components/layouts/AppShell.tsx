import { ReactNode } from 'react';
import { LayoutDashboard, Building2, Cpu, FileText, Activity, Settings, HelpCircle, ChevronDown, Bell, User } from 'lucide-react';

interface AppShellProps {
  children: ReactNode;
  title: string;
  activeNav?: string;
}

export function AppShell({ children, title, activeNav = 'dashboard' }: AppShellProps) {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-sm text-neutral-600 mb-4">{title} (1440×900)</div>
        
        {/* Frame */}
        <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-hidden flex">
          
          {/* Left Sidebar */}
          <div className="w-56 border-r-2 border-neutral-800 bg-neutral-100 flex flex-col shrink-0">
            {/* Logo */}
            <div className="h-16 border-b-2 border-neutral-800 flex items-center px-4">
              <div className="w-8 h-8 border-2 border-neutral-700 bg-neutral-300 mr-2"></div>
              <div className="text-sm text-neutral-900">Energy Monitor</div>
            </div>
            
            {/* Nav Items */}
            <div className="flex-1 py-4 space-y-1">
              <NavItem icon={<LayoutDashboard className="w-4 h-4" />} label="Dashboard" active={activeNav === 'dashboard'} />
              <NavItem icon={<Building2 className="w-4 h-4" />} label="Buildings" active={activeNav === 'buildings'} />
              <NavItem icon={<Cpu className="w-4 h-4" />} label="Appliances" active={activeNav === 'appliances'} />
              <NavItem icon={<FileText className="w-4 h-4" />} label="Reports" active={activeNav === 'reports'} />
              <NavItem icon={<Activity className="w-4 h-4" />} label="Model" active={activeNav === 'model'} />
              <NavItem icon={<Settings className="w-4 h-4" />} label="Settings" active={activeNav === 'settings'} />
              <NavItem icon={<HelpCircle className="w-4 h-4" />} label="Help" active={activeNav === 'help'} />
            </div>
            
            {/* User Section */}
            <div className="border-t-2 border-neutral-800 p-4">
              <div className="flex items-center gap-2 text-xs text-neutral-700">
                <div className="w-8 h-8 border border-neutral-600 bg-neutral-300 rounded-full"></div>
                <div>
                  <div className="text-neutral-900">John Doe</div>
                  <div className="text-neutral-600">Admin</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Main Content Area */}
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* Top Bar */}
            <div className="h-16 border-b-2 border-neutral-800 flex items-center px-6 bg-neutral-50 shrink-0 gap-4">
              {/* Building Selector */}
              <div className="flex items-center gap-2">
                <div className="text-xs text-neutral-600">Building:</div>
                <div className="border-2 border-neutral-700 bg-white px-3 py-1.5 flex items-center gap-2 min-w-[140px]">
                  <span className="text-xs">Building A</span>
                  <ChevronDown className="w-3 h-3 ml-auto" />
                </div>
              </div>
              
              {/* Date Range Picker */}
              <div className="flex items-center gap-2">
                <div className="text-xs text-neutral-600">Date:</div>
                <div className="border-2 border-neutral-700 bg-white px-3 py-1.5 flex items-center gap-2 min-w-[180px]">
                  <span className="text-xs">Jan 1 – Jan 7, 2026</span>
                  <ChevronDown className="w-3 h-3 ml-auto" />
                </div>
              </div>
              
              {/* Presets */}
              <div className="flex gap-1.5">
                <div className="px-2 py-1 border border-neutral-500 bg-neutral-100 text-xs hover:bg-neutral-200 cursor-pointer">Today</div>
                <div className="px-2 py-1 border border-neutral-500 bg-neutral-100 text-xs hover:bg-neutral-200 cursor-pointer">7d</div>
                <div className="px-2 py-1 border border-neutral-500 bg-neutral-100 text-xs hover:bg-neutral-200 cursor-pointer">30d</div>
              </div>
              
              {/* Mode Toggle */}
              <div className="ml-auto flex items-center border-2 border-neutral-700 bg-white">
                <div className="px-3 py-1.5 bg-neutral-800 text-white text-xs">Demo</div>
                <div className="px-3 py-1.5 text-xs text-neutral-600">API</div>
              </div>
              
              {/* Right Icons */}
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-neutral-600 cursor-pointer" />
                <div className="flex items-center gap-2 cursor-pointer">
                  <div className="w-8 h-8 border border-neutral-600 bg-neutral-300 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-neutral-700" />
                  </div>
                  <ChevronDown className="w-3 h-3 text-neutral-600" />
                </div>
              </div>
            </div>
            
            {/* Page Content */}
            <div className="flex-1 overflow-y-auto bg-neutral-50">
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active = false }: { icon: ReactNode; label: string; active?: boolean }) {
  return (
    <div className={`mx-2 px-3 py-2 flex items-center gap-3 text-sm cursor-pointer ${
      active ? 'bg-neutral-800 text-white' : 'text-neutral-700 hover:bg-neutral-200'
    }`}>
      {icon}
      <span>{label}</span>
    </div>
  );
}
