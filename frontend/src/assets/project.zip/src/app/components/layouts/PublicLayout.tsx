import { ReactNode } from 'react';

interface PublicLayoutProps {
  children: ReactNode;
  title: string;
}

export function PublicLayout({ children, title }: PublicLayoutProps) {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-sm text-neutral-600 mb-4">{title} (1440×900)</div>
        
        {/* Frame */}
        <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-y-auto flex flex-col">
          
          {/* Public Header */}
          <div className="h-16 border-b-2 border-neutral-800 flex items-center px-8 bg-neutral-100 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 border-2 border-neutral-700 bg-neutral-300"></div>
              <div className="text-base text-neutral-900">Energy Monitor</div>
            </div>
            
            <div className="ml-auto flex items-center gap-6 text-sm text-neutral-700">
              <div className="hover:underline cursor-pointer">Home</div>
              <div className="hover:underline cursor-pointer">About</div>
              <div className="hover:underline cursor-pointer">Docs</div>
              <div className="hover:underline cursor-pointer">Contact</div>
              <div className="ml-4 px-4 py-2 border border-neutral-700 hover:bg-neutral-50">Login</div>
              <div className="px-4 py-2 border-2 border-neutral-900 bg-neutral-800 text-white">Sign Up</div>
            </div>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {children}
          </div>
          
          {/* Public Footer */}
          <div className="h-16 border-t-2 border-neutral-800 flex items-center px-8 bg-neutral-100 text-xs text-neutral-600 shrink-0">
            <div>© 2026 Energy Monitor</div>
            <div className="ml-auto flex gap-6">
              <div className="hover:underline cursor-pointer">Privacy</div>
              <div className="hover:underline cursor-pointer">Terms</div>
              <div className="hover:underline cursor-pointer">Docs</div>
              <div className="hover:underline cursor-pointer">GitHub</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
