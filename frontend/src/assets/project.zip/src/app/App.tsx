import { useState } from 'react';
import { PublicHome } from './components/public/Home';
import { PublicAbout } from './components/public/About';
import { PublicDocs } from './components/public/Docs';
import { PublicContact } from './components/public/Contact';
import { AuthLogin } from './components/auth/Login';
import { AuthSignup } from './components/auth/Signup';
import { AuthForgotPassword } from './components/auth/ForgotPassword';
import { AuthVerifyEmail } from './components/auth/VerifyEmail';
import { AppDashboard } from './components/app/Dashboard';
import { AppApplianceDetails } from './components/app/ApplianceDetails';
import { AppBuildings } from './components/app/Buildings';
import { AppBuildingDetail } from './components/app/BuildingDetail';
import { AppReports } from './components/app/Reports';
import { AppModel } from './components/app/Model';
import { AppSettingsProfile } from './components/app/settings/Profile';
import { AppSettingsOrg } from './components/app/settings/Organization';
import { AppSettingsUsers } from './components/app/settings/Users';
import { AppHelp } from './components/app/Help';
import { UIKit } from './components/wireframe/UIKit';
import { Sitemap } from './components/wireframe/Sitemap';
import { States } from './components/wireframe/States';

type PageType = 
  // Public
  | 'public-home' | 'public-about' | 'public-docs' | 'public-contact'
  // Auth
  | 'auth-login' | 'auth-signup' | 'auth-forgot' | 'auth-verify'
  // App
  | 'app-dashboard' | 'app-appliance-details' | 'app-buildings' | 'app-building-detail'
  | 'app-reports' | 'app-model' | 'app-settings-profile' | 'app-settings-org' 
  | 'app-settings-users' | 'app-help'
  // Wireframe
  | 'ui-kit' | 'sitemap' | 'states';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('public-home');

  return (
    <div className="min-h-screen bg-neutral-200">
      {/* Wireframe Navigation */}
      <div className="fixed top-0 left-0 right-0 bg-neutral-900 text-white z-50 px-4 py-2 shadow-lg">
        <div className="flex gap-6 text-xs items-center overflow-x-auto">
          {/* Public Section */}
          <div className="flex gap-2 border-r border-neutral-600 pr-6">
            <span className="text-neutral-400 mr-2">PUBLIC:</span>
            <button onClick={() => setCurrentPage('public-home')} className={`px-2 py-1 ${currentPage === 'public-home' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Home</button>
            <button onClick={() => setCurrentPage('public-about')} className={`px-2 py-1 ${currentPage === 'public-about' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>About</button>
            <button onClick={() => setCurrentPage('public-docs')} className={`px-2 py-1 ${currentPage === 'public-docs' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Docs</button>
            <button onClick={() => setCurrentPage('public-contact')} className={`px-2 py-1 ${currentPage === 'public-contact' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Contact</button>
          </div>
          
          {/* Auth Section */}
          <div className="flex gap-2 border-r border-neutral-600 pr-6">
            <span className="text-neutral-400 mr-2">AUTH:</span>
            <button onClick={() => setCurrentPage('auth-login')} className={`px-2 py-1 ${currentPage === 'auth-login' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Login</button>
            <button onClick={() => setCurrentPage('auth-signup')} className={`px-2 py-1 ${currentPage === 'auth-signup' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Signup</button>
            <button onClick={() => setCurrentPage('auth-forgot')} className={`px-2 py-1 ${currentPage === 'auth-forgot' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Forgot</button>
            <button onClick={() => setCurrentPage('auth-verify')} className={`px-2 py-1 ${currentPage === 'auth-verify' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Verify</button>
          </div>
          
          {/* App Section */}
          <div className="flex gap-2 border-r border-neutral-600 pr-6">
            <span className="text-neutral-400 mr-2">APP:</span>
            <button onClick={() => setCurrentPage('app-dashboard')} className={`px-2 py-1 ${currentPage === 'app-dashboard' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Dashboard</button>
            <button onClick={() => setCurrentPage('app-appliance-details')} className={`px-2 py-1 ${currentPage === 'app-appliance-details' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Appliances</button>
            <button onClick={() => setCurrentPage('app-buildings')} className={`px-2 py-1 ${currentPage === 'app-buildings' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Buildings</button>
            <button onClick={() => setCurrentPage('app-building-detail')} className={`px-2 py-1 ${currentPage === 'app-building-detail' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Bldg Detail</button>
            <button onClick={() => setCurrentPage('app-reports')} className={`px-2 py-1 ${currentPage === 'app-reports' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Reports</button>
            <button onClick={() => setCurrentPage('app-model')} className={`px-2 py-1 ${currentPage === 'app-model' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Model</button>
            <button onClick={() => setCurrentPage('app-settings-profile')} className={`px-2 py-1 ${currentPage === 'app-settings-profile' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Profile</button>
            <button onClick={() => setCurrentPage('app-settings-org')} className={`px-2 py-1 ${currentPage === 'app-settings-org' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Org</button>
            <button onClick={() => setCurrentPage('app-settings-users')} className={`px-2 py-1 ${currentPage === 'app-settings-users' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Users</button>
            <button onClick={() => setCurrentPage('app-help')} className={`px-2 py-1 ${currentPage === 'app-help' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Help</button>
          </div>
          
          {/* Meta Section */}
          <div className="flex gap-2">
            <span className="text-neutral-400 mr-2">META:</span>
            <button onClick={() => setCurrentPage('ui-kit')} className={`px-2 py-1 ${currentPage === 'ui-kit' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>UI Kit</button>
            <button onClick={() => setCurrentPage('sitemap')} className={`px-2 py-1 ${currentPage === 'sitemap' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>Sitemap</button>
            <button onClick={() => setCurrentPage('states')} className={`px-2 py-1 ${currentPage === 'states' ? 'bg-neutral-700' : 'hover:bg-neutral-800'}`}>States</button>
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="pt-10">
        {/* Public Pages */}
        {currentPage === 'public-home' && <PublicHome />}
        {currentPage === 'public-about' && <PublicAbout />}
        {currentPage === 'public-docs' && <PublicDocs />}
        {currentPage === 'public-contact' && <PublicContact />}
        
        {/* Auth Pages */}
        {currentPage === 'auth-login' && <AuthLogin />}
        {currentPage === 'auth-signup' && <AuthSignup />}
        {currentPage === 'auth-forgot' && <AuthForgotPassword />}
        {currentPage === 'auth-verify' && <AuthVerifyEmail />}
        
        {/* App Pages */}
        {currentPage === 'app-dashboard' && <AppDashboard />}
        {currentPage === 'app-appliance-details' && <AppApplianceDetails />}
        {currentPage === 'app-buildings' && <AppBuildings />}
        {currentPage === 'app-building-detail' && <AppBuildingDetail />}
        {currentPage === 'app-reports' && <AppReports />}
        {currentPage === 'app-model' && <AppModel />}
        {currentPage === 'app-settings-profile' && <AppSettingsProfile />}
        {currentPage === 'app-settings-org' && <AppSettingsOrg />}
        {currentPage === 'app-settings-users' && <AppSettingsUsers />}
        {currentPage === 'app-help' && <AppHelp />}
        
        {/* Wireframe Pages */}
        {currentPage === 'ui-kit' && <UIKit />}
        {currentPage === 'sitemap' && <Sitemap />}
        {currentPage === 'states' && <States />}
      </div>
    </div>
  );
}
