import { useState } from 'react';
import { Home } from './components/Home';
import { Dashboard } from './components/Dashboard';
import { Details } from './components/Details';
import { Sitemap } from './components/Sitemap';
import { States } from './components/States';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'dashboard' | 'details' | 'sitemap' | 'states'>('home');

  return (
    <div className="min-h-screen bg-neutral-100">
      {/* Wireframe Navigation */}
      <div className="fixed top-0 left-0 right-0 bg-neutral-800 text-white z-50 px-4 py-2 flex gap-4 text-sm">
        <button 
          onClick={() => setCurrentPage('home')} 
          className={`px-3 py-1 ${currentPage === 'home' ? 'bg-neutral-600' : 'hover:bg-neutral-700'}`}
        >
          Home
        </button>
        <button 
          onClick={() => setCurrentPage('dashboard')} 
          className={`px-3 py-1 ${currentPage === 'dashboard' ? 'bg-neutral-600' : 'hover:bg-neutral-700'}`}
        >
          Dashboard
        </button>
        <button 
          onClick={() => setCurrentPage('details')} 
          className={`px-3 py-1 ${currentPage === 'details' ? 'bg-neutral-600' : 'hover:bg-neutral-700'}`}
        >
          Details
        </button>
        <div className="ml-auto flex gap-4">
          <button 
            onClick={() => setCurrentPage('sitemap')} 
            className={`px-3 py-1 ${currentPage === 'sitemap' ? 'bg-neutral-600' : 'hover:bg-neutral-700'}`}
          >
            Sitemap
          </button>
          <button 
            onClick={() => setCurrentPage('states')} 
            className={`px-3 py-1 ${currentPage === 'states' ? 'bg-neutral-600' : 'hover:bg-neutral-700'}`}
          >
            States
          </button>
        </div>
      </div>

      <div className="pt-12">
        {currentPage === 'home' && <Home />}
        {currentPage === 'dashboard' && <Dashboard />}
        {currentPage === 'details' && <Details />}
        {currentPage === 'sitemap' && <Sitemap />}
        {currentPage === 'states' && <States />}
      </div>
    </div>
  );
}
