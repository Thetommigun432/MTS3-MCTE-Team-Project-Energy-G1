import { Menu } from 'lucide-react';

export function Home() {
  return (
    <div className="bg-neutral-100">
      {/* Desktop and Mobile Frames */}
      <div className="p-8 space-y-12">
        
        {/* DESKTOP FRAME - 1440x900 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Home – Desktop (1440×900)</h2>
          <div className="w-[1440px] h-[900px] bg-white border-4 border-neutral-900 mx-auto overflow-hidden">
            
            {/* Top Navigation */}
            <div className="h-16 border-b-2 border-neutral-800 flex items-center px-8 bg-neutral-200">
              <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
              <div className="text-lg text-neutral-800">Energy Monitor</div>
              <div className="ml-auto flex gap-8 text-sm text-neutral-700">
                <div className="underline">Home</div>
                <div>Dashboard</div>
                <div>Details</div>
              </div>
            </div>
            
            {/* Hero Section */}
            <div className="h-64 border-b-2 border-neutral-400 flex items-center justify-center bg-neutral-100">
              <div className="text-center space-y-4">
                <div className="text-3xl text-neutral-900">Energy Monitor</div>
                <div className="text-sm text-neutral-600 max-w-md">
                  NILM Dashboard – Identify appliances from total consumption
                </div>
                <div className="mt-6">
                  <div className="inline-block px-8 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-sm">
                    Open Dashboard →
                  </div>
                </div>
              </div>
            </div>
            
            {/* Content Sections */}
            <div className="grid grid-cols-3 gap-8 p-12">
              
              {/* Section 1: Problem */}
              <div className="space-y-3">
                <div className="text-sm text-neutral-900 border-b border-neutral-400 pb-2">
                  1. Problem
                </div>
                <div className="text-xs text-neutral-700 leading-relaxed">
                  Which appliances are ON from total consumption?
                </div>
                <div className="h-24 border border-neutral-400 bg-neutral-50 flex items-center justify-center text-xs text-neutral-500">
                  [Diagram placeholder]
                </div>
              </div>
              
              {/* Section 2: How it Works */}
              <div className="space-y-3">
                <div className="text-sm text-neutral-900 border-b border-neutral-400 pb-2">
                  2. How it works
                </div>
                <div className="space-y-2 text-xs text-neutral-700">
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">1</div>
                    <div>Collect total building energy data</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">2</div>
                    <div>AI model analyzes consumption patterns</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-5 h-5 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0">3</div>
                    <div>View predictions in dashboard</div>
                  </div>
                </div>
              </div>
              
              {/* Section 3: What You Get */}
              <div className="space-y-3">
                <div className="text-sm text-neutral-900 border-b border-neutral-400 pb-2">
                  3. What you get
                </div>
                <div className="space-y-2 text-xs text-neutral-700">
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Real-time appliance ON/OFF status</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Estimated kW per appliance</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Historical insights & trends</div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2 h-2 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Model confidence metrics</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Footer */}
            <div className="absolute bottom-0 left-0 right-0 h-12 border-t-2 border-neutral-400 bg-neutral-200 flex items-center px-8">
              <div className="text-xs text-neutral-600">© 2026 Energy Monitor | Terms | Privacy</div>
            </div>
          </div>
        </div>
        
        {/* MOBILE FRAME - 390x844 */}
        <div>
          <h2 className="text-xl mb-4 text-neutral-700">Home – Mobile (390×844)</h2>
          <div className="w-[390px] h-[844px] bg-white border-4 border-neutral-900 mx-auto overflow-hidden">
            
            {/* Top Navigation */}
            <div className="h-14 border-b-2 border-neutral-800 flex items-center px-4 bg-neutral-200 justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 border-2 border-neutral-700 bg-neutral-300"></div>
                <div className="text-sm text-neutral-800">Energy Monitor</div>
              </div>
              <Menu className="w-6 h-6 text-neutral-800" />
            </div>
            
            {/* Hero Section */}
            <div className="p-6 border-b-2 border-neutral-400 bg-neutral-100">
              <div className="text-center space-y-4">
                <div className="text-xl text-neutral-900">Energy Monitor</div>
                <div className="text-xs text-neutral-600">
                  NILM Dashboard – Identify appliances from total consumption
                </div>
                <div className="mt-4">
                  <div className="px-6 py-3 border-2 border-neutral-900 bg-neutral-800 text-white text-xs text-center">
                    Open Dashboard →
                  </div>
                </div>
              </div>
            </div>
            
            {/* Content Sections - Stacked */}
            <div className="p-6 space-y-6">
              
              {/* Section 1 */}
              <div className="space-y-2">
                <div className="text-xs text-neutral-900 border-b border-neutral-400 pb-1">
                  1. Problem
                </div>
                <div className="text-xs text-neutral-700">
                  Which appliances are ON from total consumption?
                </div>
                <div className="h-20 border border-neutral-400 bg-neutral-50 flex items-center justify-center text-xs text-neutral-500">
                  [Diagram]
                </div>
              </div>
              
              {/* Section 2 */}
              <div className="space-y-2">
                <div className="text-xs text-neutral-900 border-b border-neutral-400 pb-1">
                  2. How it works
                </div>
                <div className="space-y-1.5 text-xs text-neutral-700">
                  <div className="flex gap-2">
                    <div className="w-4 h-4 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0 text-[10px]">1</div>
                    <div>Collect total building energy data</div>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-4 h-4 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0 text-[10px]">2</div>
                    <div>AI model analyzes patterns</div>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-4 h-4 border border-neutral-600 bg-neutral-200 flex items-center justify-center shrink-0 text-[10px]">3</div>
                    <div>View predictions in dashboard</div>
                  </div>
                </div>
              </div>
              
              {/* Section 3 */}
              <div className="space-y-2">
                <div className="text-xs text-neutral-900 border-b border-neutral-400 pb-1">
                  3. What you get
                </div>
                <div className="space-y-1.5 text-xs text-neutral-700">
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Real-time appliance status</div>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Estimated kW per appliance</div>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Historical insights & trends</div>
                  </div>
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 border border-neutral-600 bg-neutral-800 mt-1 shrink-0"></div>
                    <div>Confidence metrics</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Footer */}
            <div className="absolute bottom-0 left-0 right-0 h-10 border-t-2 border-neutral-400 bg-neutral-200 flex items-center px-4">
              <div className="text-[10px] text-neutral-600">© 2026 Energy Monitor</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
