import { ChevronDown, Loader2, AlertCircle } from 'lucide-react';

export function States() {
  return (
    <div className="p-8 bg-neutral-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl mb-8 text-neutral-800">Dashboard States</h1>
        
        <div className="grid grid-cols-2 gap-6">
          
          {/* STATE 1: LOADING */}
          <div>
            <h2 className="text-lg mb-3 text-neutral-700">Loading State</h2>
            <div className="w-[720px] h-[560px] bg-white border-4 border-neutral-900 overflow-hidden">
              
              {/* Top Nav */}
              <div className="h-16 border-b-2 border-neutral-800 bg-neutral-200 flex items-center px-8">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
                <div className="text-lg text-neutral-800">Energy Monitor</div>
              </div>
              
              {/* Header Area - Disabled Controls */}
              <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-xl text-neutral-900">Dashboard</div>
                  <div className="flex items-center gap-3 border-2 border-neutral-700 bg-white">
                    <div className="px-4 py-2 bg-neutral-800 text-white text-xs">Demo Mode</div>
                    <div className="px-4 py-2 text-xs text-neutral-600">API Mode</div>
                  </div>
                </div>
                
                {/* Disabled Controls */}
                <div className="flex gap-3 opacity-40">
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Building</div>
                    <div className="border-2 border-neutral-700 bg-neutral-100 px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Building A</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Date Range</div>
                    <div className="border-2 border-neutral-700 bg-neutral-100 px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Jan 1 – Jan 7</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex items-end">
                    <div className="px-6 py-2 border-2 border-neutral-900 bg-neutral-300 text-neutral-500 text-xs">
                      Apply
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Loading Overlay */}
              <div className="h-[400px] bg-neutral-100 flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="w-12 h-12 text-neutral-700 animate-spin mx-auto mb-4" />
                  <div className="text-sm text-neutral-800">Loading data...</div>
                  <div className="text-xs text-neutral-600 mt-1">Please wait</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 2: API MODE BANNER */}
          <div>
            <h2 className="text-lg mb-3 text-neutral-700">API Mode – Connecting</h2>
            <div className="w-[720px] h-[560px] bg-white border-4 border-neutral-900 overflow-hidden">
              
              {/* Top Nav */}
              <div className="h-16 border-b-2 border-neutral-800 bg-neutral-200 flex items-center px-8">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
                <div className="text-lg text-neutral-800">Energy Monitor</div>
              </div>
              
              {/* API Mode Banner - Yellow */}
              <div className="bg-yellow-100 border-b-2 border-yellow-400 px-8 py-3">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-yellow-800 animate-spin" />
                  <div>
                    <div className="text-sm text-yellow-900">API Mode — Connecting to backend...</div>
                    <div className="text-xs text-yellow-800 mt-0.5">Attempting to fetch live data from API endpoint</div>
                  </div>
                </div>
              </div>
              
              {/* Header Area */}
              <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-xl text-neutral-900">Dashboard</div>
                  <div className="flex items-center gap-3 border-2 border-neutral-700 bg-white">
                    <div className="px-4 py-2 text-xs text-neutral-600">Demo Mode</div>
                    <div className="px-4 py-2 bg-neutral-800 text-white text-xs">API Mode</div>
                  </div>
                </div>
                
                {/* Controls */}
                <div className="flex gap-3 opacity-60">
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Building</div>
                    <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Building A</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Date Range</div>
                    <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Jan 1 – Jan 7</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Content Placeholder */}
              <div className="p-8 space-y-4">
                <div className="grid grid-cols-4 gap-3">
                  <div className="h-20 border-2 border-neutral-400 bg-neutral-100"></div>
                  <div className="h-20 border-2 border-neutral-400 bg-neutral-100"></div>
                  <div className="h-20 border-2 border-neutral-400 bg-neutral-100"></div>
                  <div className="h-20 border-2 border-neutral-400 bg-neutral-100"></div>
                </div>
                <div className="h-32 border-2 border-neutral-400 bg-neutral-100"></div>
              </div>
            </div>
          </div>
          
          {/* STATE 3: ERROR */}
          <div>
            <h2 className="text-lg mb-3 text-neutral-700">Error State</h2>
            <div className="w-[720px] h-[560px] bg-white border-4 border-neutral-900 overflow-hidden">
              
              {/* Top Nav */}
              <div className="h-16 border-b-2 border-neutral-800 bg-neutral-200 flex items-center px-8">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
                <div className="text-lg text-neutral-800">Energy Monitor</div>
              </div>
              
              {/* Error Banner - Red */}
              <div className="bg-red-100 border-b-2 border-red-400 px-8 py-3">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-800" />
                  <div>
                    <div className="text-sm text-red-900">Failed to load data</div>
                    <div className="text-xs text-red-800 mt-0.5">
                      API connection failed — switch to Demo Mode or check your connection
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Header Area */}
              <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-xl text-neutral-900">Dashboard</div>
                  <div className="flex items-center gap-3 border-2 border-neutral-700 bg-white">
                    <div className="px-4 py-2 text-xs text-neutral-600 underline cursor-pointer">
                      Switch to Demo Mode
                    </div>
                    <div className="px-4 py-2 bg-neutral-800 text-white text-xs">API Mode</div>
                  </div>
                </div>
              </div>
              
              {/* Error Content */}
              <div className="h-[400px] bg-neutral-100 flex items-center justify-center">
                <div className="text-center max-w-sm">
                  <AlertCircle className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                  <div className="text-sm text-neutral-800 mb-2">Unable to load data</div>
                  <div className="text-xs text-neutral-600 mb-4">
                    The API endpoint is not responding. Please try again or switch to Demo Mode.
                  </div>
                  <div className="flex gap-2 justify-center">
                    <div className="px-4 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs">
                      Retry
                    </div>
                    <div className="px-4 py-2 border border-neutral-500 bg-white text-xs">
                      Demo Mode
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* STATE 4: EMPTY DATA */}
          <div>
            <h2 className="text-lg mb-3 text-neutral-700">Empty Data State</h2>
            <div className="w-[720px] h-[560px] bg-white border-4 border-neutral-900 overflow-hidden">
              
              {/* Top Nav */}
              <div className="h-16 border-b-2 border-neutral-800 bg-neutral-200 flex items-center px-8">
                <div className="w-12 h-12 border-2 border-neutral-700 bg-neutral-300 mr-4"></div>
                <div className="text-lg text-neutral-800">Energy Monitor</div>
              </div>
              
              {/* Header Area */}
              <div className="border-b-2 border-neutral-400 px-8 py-4 bg-neutral-50">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-xl text-neutral-900">Dashboard</div>
                  <div className="flex items-center gap-3 border-2 border-neutral-700 bg-white">
                    <div className="px-4 py-2 bg-neutral-800 text-white text-xs">Demo Mode</div>
                    <div className="px-4 py-2 text-xs text-neutral-600">API Mode</div>
                  </div>
                </div>
                
                {/* Controls */}
                <div className="flex gap-3">
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Building</div>
                    <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Building A</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-xs text-neutral-700 mb-1">Date Range</div>
                    <div className="border-2 border-neutral-700 bg-white px-3 py-2 flex items-center justify-between">
                      <span className="text-xs">Dec 1 – Dec 7, 2025</span>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </div>
                  
                  <div className="flex items-end">
                    <div className="px-6 py-2 border-2 border-neutral-900 bg-neutral-800 text-white text-xs">
                      Apply
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Empty State Content */}
              <div className="h-[400px] bg-neutral-50 flex items-center justify-center">
                <div className="text-center max-w-md">
                  <div className="w-20 h-20 border-2 border-neutral-500 bg-neutral-200 mx-auto mb-4 flex items-center justify-center">
                    <div className="text-3xl text-neutral-500">?</div>
                  </div>
                  <div className="text-sm text-neutral-800 mb-2">No data in this date range</div>
                  <div className="text-xs text-neutral-600 mb-4">
                    There is no energy consumption data for Building A between Dec 1 – Dec 7, 2025.
                    Try selecting a different date range or building.
                  </div>
                  <div className="px-4 py-2 border border-neutral-500 bg-white text-xs inline-block">
                    Change Filters
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        
        {/* Legend/Notes */}
        <div className="mt-8 p-6 bg-white border-2 border-neutral-700">
          <div className="text-sm text-neutral-900 mb-3">State Notes</div>
          <div className="space-y-2 text-xs text-neutral-700">
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Loading:</strong> Disabled controls, spinner overlay, "Loading data..." message</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>API Mode:</strong> Yellow banner with connecting status, controls semi-enabled</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Error:</strong> Red banner with error message, retry and demo mode options</div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 bg-neutral-800 rounded-full mt-1.5"></div>
              <div><strong>Empty Data:</strong> Clean empty state with helpful messaging and guidance to change filters</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
